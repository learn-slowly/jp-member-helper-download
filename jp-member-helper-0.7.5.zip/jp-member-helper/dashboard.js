// 화면: 당비 미납자 / 당원현황 / 당비현황 / 설정. 계산은 전부 core.js.
// 사이트에서 온 글자(이름 등)는 textContent로만 넣는다(HTML로 해석하지 않음).
import * as core from './core.js';

const $ = (id) => document.getElementById(id);
const XLSX = globalThis.XLSX;

// 작은 DOM 도구: h('span', { class: 'x' }, '글자', 자식…)
function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'checked') el.checked = Boolean(v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) el.append(k instanceof Node ? k : String(k));
  return el;
}

function toast(text) {
  const t = $('toast');
  t.textContent = text;
  t.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (t.hidden = true), 3500);
}

const today = () => core.localDate(new Date());

let store = {};
async function reload() {
  store = await chrome.storage.local.get(null);
}
const settings = () => ({ ...core.DEFAULT_SETTINGS, ...(store.settings || {}) });

// ------------------------------------------------------------------ 머리(상태 줄·지금 확인)

function renderTop() {
  const st = store.status;
  const last = store.meta?.lastSync && !st?.busy
    ? ` · 마지막 확인 ${new Date(store.meta.lastSync).toLocaleString('ko-KR', { month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`
    : '';
  $('status').textContent = (st?.text || '아직 확인한 적이 없습니다.') + last;
  $('check').disabled = Boolean(st?.busy);
}

$('check').addEventListener('click', async () => {
  $('check').disabled = true;
  $('status').textContent = '자료를 받는 중입니다… (1~2분)';
  const res = await chrome.runtime.sendMessage({ type: 'check' });
  if (res && !res.ok) toast(res.text);
});

// ------------------------------------------------------------------ 탭

const TABS = ['lapsed', 'members', 'fee', 'settings'];
function showTab(name) {
  for (const t of TABS) {
    $(t).hidden = t !== name;
    $(`tab-${t}`).setAttribute('aria-selected', String(t === name));
  }
  try {
    localStorage.setItem('tab', name);
  } catch {
    /* 저장 못 해도 괜찮음 */
  }
}
for (const t of TABS) $(`tab-${t}`).addEventListener('click', () => showTab(t));

// ------------------------------------------------------------------ 당비 미납자

let lapsedRes = null;

function contactedSet(cur) {
  const s = new Set();
  for (const k of Object.keys(store.contacted || {})) if (k.startsWith(`${cur}:`)) s.add(k.slice(cur.length + 1));
  return s;
}

function filters() {
  return {
    region: $('f-region').value,
    kind: $('f-kind').value,
    hideContacted: $('f-hide').checked,
    priorAll: $('f-prior').checked,
    q: $('f-q').value,
  };
}

let kindDefaulted = false; // 구분 기본값을 한 번만 넣기 위함

function fillSelect(sel, values, labelOf = (v) => v) {
  const keep = sel.value;
  sel.replaceChildren(sel.options[0] || h('option', { value: '' }, '전체'));
  for (const v of values) sel.append(h('option', { value: v }, labelOf(v)));
  if ([...sel.options].some((o) => o.value === keep)) sel.value = keep;
}

function renderLapsed() {
  if (!store.members || !store.fee) {
    $('lapsed-empty').textContent = '아직 자료가 없습니다. 당원관리 시스템(cs.justice21.org)에 로그인한 뒤 위의 [지금 확인]을 눌러 주세요.';
    $('lapsed-empty').hidden = false;
    $('lapsed-body').hidden = true;
    return;
  }
  $('lapsed-empty').hidden = true;
  $('lapsed-body').hidden = false;
  const s = settings();
  lapsedRes = core.findLapsed({ feeByMonth: store.fee, members: store.members.rows, today: today(), prior: s.prior });
  const { cur, last, counts: c } = lapsedRes;
  const contacted = contactedSet(cur);
  const left = lapsedRes.list.filter((x) => x.counted && !contacted.has(x.id)).length;

  $('big').textContent = `미납 ${c.total}명` + (c.total ? ` · 아직 연락 안 함 ${left}명` : '');
  const parts = [
    `${core.KIND.BOTH} ${c[core.KIND.BOTH]}명`,
    `${core.KIND.LAST} ${c[core.KIND.LAST]}명`,
    `${core.KIND.CUR} ${c[core.KIND.CUR]}명`,
  ];
  if (c.waiting) parts.push(`인출 대기 ${c.waiting}명(아직 미납으로 세지 않음)`);
  if (c.gone) parts.push(`명단에 없음 ${c.gone}명`);
  $('kinds').textContent = parts.join(' · ');
  $('f-prior').parentElement.lastChild.textContent = ` 지난 ${s.prior}개월 모두 납부한 사람만`;

  fillSelect($('f-region'), core.regionSort(new Set(lapsedRes.list.map((x) => x.region))));
  fillSelect($('f-kind'), [core.KIND.BOTH, core.KIND.LAST, core.KIND.CUR, core.KIND.WAIT]);
  // 화면을 열 때 처음에는 '지난달만 미납'만 보여 준다(다 보려면 구분에서 '전체')
  if (!kindDefaulted) {
    $('f-kind').value = core.KIND.LAST;
    kindDefaulted = true;
  }

  const shown = core.filterLapsed(lapsedRes.list, filters(), contacted);
  $('shown').textContent = shown.length === lapsedRes.list.length ? '' : `조건에 맞는 사람 ${shown.length}명`;

  const months = core.monthsNeeded(cur, s.prior);
  // '신규' = 이번 달에 처음 미납으로 잡힌 사람(그달 내내 표시, 2026-11-04 결정)
  const fresh = new Set(store.notified?.[cur] || []);
  const list = $('lapsed-list');
  const openState = Object.fromEntries([...list.querySelectorAll('details')].map((d) => [d.dataset.key, d.open]));
  list.replaceChildren();

  if (!lapsedRes.list.length) {
    list.append(h('div', { class: 'empty' }, '지금은 당비 미납자가 없습니다.'));
    return;
  }
  if (!shown.length) {
    list.append(h('div', { class: 'empty' }, '조건에 맞는 사람이 없습니다. 위의 필터를 바꿔 보세요.'));
    return;
  }

  const groups = new Map();
  for (const x of shown) {
    const key = x.inList ? x.region : '__gone';
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(x);
  }
  // 미납자가 있는 지역을 먼저, 인출 대기만 있는 지역은 뒤로, 명단에 없음은 맨 뒤
  const rank = ([key, people]) => (key === '__gone' ? 2 : people.some((x) => x.counted) ? 0 : 1);
  const ordered = [...groups].sort((a, b) => rank(a) - rank(b)); // 같은 순위 안에서는 지역 순서 유지
  for (const [key, people] of ordered) {
    const gone = key === '__gone';
    const counted = people.filter((x) => x.counted).length;
    const label = gone ? '명단에 없음(탈당 등) — 숫자·알림에서 뺌' : key;
    const d = h('details', { class: `group${gone ? ' gone' : ''}`, 'data-key': key },
      h('summary', {}, label, h('span', { class: 'count' }, gone ? `${people.length}명` : `미납 ${counted}명${people.length > counted ? ` · 대기 ${people.length - counted}명` : ''}`)));
    // 인출 대기만 있는 묶음과 명단에 없음 묶음은 접어 둔다
    d.open = openState[key] ?? (!gone && counted > 0);
    for (const x of people) d.append(personRow(x, { cur, last, prior: s.prior, months, contacted, fresh }));
    list.append(d);
  }
}

function personRow(x, { cur, last, prior, months, contacted, fresh }) {
  const done = contacted.has(x.id);
  const cells = months.map((m) => {
    const label = `${Number(m.slice(5))}월`;
    if (m in x.paid) return h('span', { class: 'paid', title: `${core.monthLabel(m)} 냄` }, `✓ ${label}`);
    if (m === cur && x.kind !== core.KIND.BOTH && x.kind !== core.KIND.CUR && x.draw) {
      return h('span', { class: 'wait', title: '아직 인출 전' }, `${label} 대기`);
    }
    if (m === last || (m === cur && x.missCur)) return h('span', { class: 'miss', title: `${core.monthLabel(m)} 안 냄` }, label);
    return h('span', { title: `${core.monthLabel(m)} 안 냄` }, label);
  });
  const box = h('input', {
    type: 'checkbox',
    checked: done,
    onchange: (e) => setContacted(cur, x.id, e.target.checked),
  });
  const tags = [];
  if (fresh.has(x.id) && x.counted) tags.push(h('span', { class: 'tag new' }, '신규'));
  if (x.kind === core.KIND.WAIT) tags.push(h('span', { class: 'tag wait' }, '인출 대기'));
  return h('div', { class: `person${done ? ' done' : ''}${x.kind === core.KIND.WAIT ? ' waiting' : ''}` },
    h('p', { class: 'line' }, h('span', { class: 'name' }, x.name || `(이름 없음 ${x.id})`), ...tags, core.lapsedParts(x, { cur, last, prior }).join(' · ')),
    h('label', { class: 'contact' }, box, '연락함'),
    h('div', { class: 'months', 'aria-label': '달별 납부' }, cells));
}

async function setContacted(cur, id, on) {
  // 화면이 들고 있는 값이 아니라 저장소에서 바로 읽는다(빠르게 두 번 눌러도 앞의 표시가 사라지지 않게)
  const contacted = { ...((await chrome.storage.local.get('contacted')).contacted || {}) };
  const key = `${cur}:${id}`;
  if (on) contacted[key] = Date.now();
  else delete contacted[key];
  // 지난달 이전 표시는 정리(이번 달 기준으로 저장)
  for (const k of Object.keys(contacted)) if (k.slice(0, 7) < core.monthAdd(cur, -3)) delete contacted[k];
  await chrome.storage.local.set({ contacted });
  chrome.runtime.sendMessage({ type: 'badge' });
}

for (const id of ['f-region', 'f-kind', 'f-hide', 'f-prior']) $(id).addEventListener('change', renderLapsed);
$('f-q').addEventListener('input', renderLapsed);

$('lapsed-xlsx').addEventListener('click', () => {
  if (!lapsedRes) return;
  const { cur } = lapsedRes;
  // 필터와 상관없이 명단 전체를 저장한다(PRD 3.2)
  const aoa = core.lapsedAoa(lapsedRes.list, { cur, prior: settings().prior }, contactedSet(cur));
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = aoa[0].map((hd, i) => ({ wch: i === 10 ? 20 : i === 3 ? 14 : Math.max(8, String(hd).length + 2) }));
  ws['!autofilter'] = { ref: ws['!ref'] };
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, '미납자 명단');
  XLSX.writeFile(wb, `당비미납_${cur}_${today()}.xlsx`);
  toast('명단 전체를 엑셀로 내려받았습니다. 이름·연락처가 들어 있으니 다른 곳에 올리지 마세요.');
});

// ------------------------------------------------------------------ 표 그리기·복사·엑셀 공용

// head: [[{text, rowspan, colspan}|문자, …], …], body: [[문자…]…] (마지막 줄 = 총계)
function drawTable(table, head, body, { total = true, totals = 1 } = {}) {
  table.replaceChildren();
  const thead = h('thead');
  for (const row of head) {
    thead.append(h('tr', {}, row.map((c) => (typeof c === 'string'
      ? h('th', {}, c)
      : h('th', { rowspan: c.rowspan, colspan: c.colspan }, c.text)))));
  }
  const tbody = h('tbody');
  body.forEach((r, i) => {
    tbody.append(h('tr', { class: total && i >= body.length - totals ? 'total' : null }, r.map((v, j) => h('td', {
      class: j === r.length - 1 && head[0].some((c) => (c.text || c) === '비고') ? 'note' : /^-\d/.test(v) ? 'neg' : null,
    }, v))));
  });
  table.append(thead, tbody);
}

// 한글에 붙여넣을 수 있게 HTML 표(선 있음) + 일반 글자(탭 구분) 둘 다 클립보드에
async function copyTable(head, body, title) {
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
  const td = 'border:1px solid #000;padding:2px 6px;';
  let html = `<table style="border-collapse:collapse;font-size:10pt">`;
  for (const row of head) {
    html += '<tr>' + row.map((c) => (typeof c === 'string'
      ? `<th style="${td}background:#eee">${esc(c)}</th>`
      : `<th style="${td}background:#eee"${c.rowspan ? ` rowspan="${c.rowspan}"` : ''}${c.colspan ? ` colspan="${c.colspan}"` : ''}>${esc(c.text)}</th>`)).join('') + '</tr>';
  }
  for (const r of body) {
    html += '<tr>' + r.map((v, j) => `<td style="${td}text-align:${j === 0 ? 'left' : 'right'}">${esc(v)}</td>`).join('') + '</tr>';
  }
  html += '</table>';
  const text = [title, ...head.map((r) => r.map((c) => (typeof c === 'string' ? c : c.text.replace(/\n/g, ' '))).join('\t')), ...body.map((r) => r.join('\t'))].filter(Boolean).join('\n');
  try {
    await navigator.clipboard.write([new ClipboardItem({
      'text/html': new Blob([html], { type: 'text/html' }),
      'text/plain': new Blob([text], { type: 'text/plain' }),
    })]);
    toast('표를 복사했습니다. 한글에서 붙여넣기(Ctrl+V, 맥은 ⌘+V) 하세요.');
  } catch {
    toast('복사하지 못했습니다. 화면을 한 번 누른 뒤 다시 눌러 주세요.');
  }
}

// 2단 머리를 엑셀 칸 합치기로
function headToAoa(head) {
  const width = head[0].reduce((s, c) => s + (typeof c === 'string' ? 1 : c.colspan || 1), 0);
  const grid = head.map(() => Array(width).fill(''));
  const merges = [];
  const taken = head.map(() => Array(width).fill(false));
  head.forEach((row, r) => {
    let col = 0;
    for (const c of row) {
      while (taken[r][col]) col += 1;
      const text = typeof c === 'string' ? c : c.text.replace(/\n/g, '');
      const rs = (typeof c === 'string' ? 1 : c.rowspan) || 1;
      const cs = (typeof c === 'string' ? 1 : c.colspan) || 1;
      grid[r][col] = text;
      for (let i = 0; i < rs; i++) for (let j = 0; j < cs; j++) taken[r + i][col + j] = true;
      if (rs > 1 || cs > 1) merges.push({ s: { r, c: col }, e: { r: r + rs - 1, c: col + cs - 1 } });
      col += cs;
    }
  });
  return { grid, merges };
}

function saveTableXlsx({ head, body, notes, title, sheet, file }) {
  const { grid, merges } = headToAoa(head);
  const top = title ? [[title], []] : [];
  const aoa = [...top, ...grid, ...body, [], ...notes.map((n) => [`※ ${n}`])];
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!merges'] = merges.map((m) => ({ s: { r: m.s.r + top.length, c: m.s.c }, e: { r: m.e.r + top.length, c: m.e.c } }));
  ws['!cols'] = grid[0].map((_, i) => ({ wch: i === 0 ? 14 : 11 }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheet);
  XLSX.writeFile(wb, file);
  toast('엑셀 파일을 내려받았습니다.');
}

// ------------------------------------------------------------------ 당원현황

let memberView = null;
let memberCompare = null; // 사용자가 고른 비교 기준일(안 골랐으면 가장 최근 기록)

function renderMembers() {
  const ledger = store.ledger || core.seedLedger();
  const dates = core.ledgerDates(ledger);
  const date = dates.at(-1);
  if (!date) {
    $('m-compare').replaceChildren();
    $('m-title').textContent = '아직 기록이 없습니다. 당원관리 시스템에 로그인한 뒤 [지금 확인]을 눌러 주세요. 그다음 설정 → [출발점 만들기]를 한 번 누르면 9기 누계와 올해 누계가 나옵니다.';
    $('m-summary').textContent = '';
    $('m-table').replaceChildren();
    $('m-notes').replaceChildren();
    memberView = null;
    return;
  }
  const earlier = dates.filter((d) => d < date);
  const sel = $('m-compare');
  sel.replaceChildren(...earlier.slice().reverse().map((d) => h('option', { value: d }, d)));
  if (memberCompare && earlier.includes(memberCompare)) sel.value = memberCompare;
  const s = settings();
  const rep = core.memberReport({ ledger, date, compareDate: sel.value || null, termStart: s.termStart, yearStart: s.yearStart });
  if (!rep) return;
  const t = core.memberReportTable(rep);
  const title = `당원현황 (${date} 기준)`;
  $('m-title').textContent = store.members ? `${date} 기록 기준` : `${date} 기록 기준 — 아직 [지금 확인]을 하지 않아 가져온 장부의 숫자입니다.`;
  $('m-summary').textContent = rep.summary;
  drawTable($('m-table'), [t.head1, t.head2], t.body);
  $('m-notes').replaceChildren(...t.notes.map((n) => h('li', {}, n)));
  memberView = { head: [t.head1, t.head2], body: t.body, notes: [rep.summary, ...t.notes], title, date };
}

$('m-compare').addEventListener('change', () => {
  memberCompare = $('m-compare').value;
  renderMembers();
  renderRights();
});
$('m-copy').addEventListener('click', () => memberView && copyTable(memberView.head, memberView.body, ''));
$('m-xlsx').addEventListener('click', () => memberView && saveTableXlsx({
  ...memberView, sheet: '당원현황', file: `당원현황_${memberView.date}.xlsx`,
}));

// ------------------------------------------------------------------ 당비현황

// 평생당비 제외(설정에 기억). 체크하면 당비현황의 모든 표에서 평생특별당비를 뺀다.
const LIFETIME = '평생특별당비';
const feeExclude = () => (settings().excludeLifetime ? [LIFETIME] : []);
const exNote = () => (feeExclude().length ? ['평생특별당비는 빼고 셌습니다.'] : []);

let feeView = null;

function renderFee() {
  const months = Object.keys(store.fee || {}).sort().reverse();
  if (!months.length) {
    $('fee-empty').hidden = false;
    $('fee-body').hidden = true;
    return;
  }
  $('fee-empty').hidden = true;
  $('fee-body').hidden = false;
  const sel = $('fee-month');
  const keep = sel.value;
  sel.replaceChildren(...months.map((m) => h('option', { value: m }, `${m.slice(0, 4)}년 ${Number(m.slice(5))}월`)));
  const lastMonth = core.monthAdd(core.monthOf(today()), -1);
  sel.value = months.includes(keep) ? keep : months.includes(lastMonth) ? lastMonth : months[0];
  // 줄은 당원 명단에 있는 지역으로(그달 낸 사람이 0명이어도 줄을 남김)
  const regions = store.members ? Object.keys(core.regionCounts(store.members.rows)).filter((r) => r !== core.NO_REGION) : [];
  const rep = core.feeReport({ fee: store.fee, special: store.special, month: sel.value, exclude: feeExclude(), regions });
  const t = core.feeReportTable(rep);
  t.notes.push(...exNote());
  $('fee-nolife').checked = Boolean(settings().excludeLifetime);
  drawTable($('fee-table'), [t.head], t.body);
  $('fee-notes').replaceChildren(...t.notes.map((n) => h('li', {}, n)));
  feeView = { head: [t.head], body: t.body, notes: t.notes, title: `당비현황 (${sel.value})${feeExclude().length ? ' — 평생당비 제외' : ''}`, month: sel.value };
}

$('fee-month').addEventListener('change', renderFee);
$('fee-copy').addEventListener('click', () => feeView && copyTable(feeView.head, feeView.body, ''));
$('fee-xlsx').addEventListener('click', () => feeView && saveTableXlsx({
  ...feeView, sheet: '당비현황', file: `당비현황_${feeView.month}.xlsx`,
}));

// ------------------------------------------------------------------ 설정

function renderSettings() {
  const s = settings();
  for (const r of document.querySelectorAll('input[name=schedule]')) r.checked = r.value === s.schedule;
  if (document.activeElement !== $('s-term')) $('s-term').value = s.termStart || '';
  if (document.activeElement !== $('s-year')) $('s-year').value = s.yearStart || '';
  $('y-dates').textContent = `9기 시작일 ${s.termStart} · 올해 시작일 ${s.yearStart || `${today().slice(0, 4)}-01-01`} (위 '누계 기준일'에서 바꿀 수 있습니다)`;
  const items = [];
  items.push(store.members
    ? `당원 명단: ${core.fmtNum(store.members.rows.length)}명 (${store.members.date} 받음)`
    : '당원 명단: 아직 없음');
  const fm = Object.keys(store.fee || {}).sort();
  items.push(`당비 내역: ${fm.length ? fm.map((m) => `${Number(m.slice(5))}월`).join(', ') : '아직 없음'}`);
  const ld = core.ledgerDates(store.ledger || []);
  items.push(`장부 기록일: ${ld.length}개 (${ld[0] || '-'} ~ ${ld.at(-1) || '-'})`);
  items.push(`연락함 표시: ${Object.keys(store.contacted || {}).length}건`);
  $('s-summary').replaceChildren(...items.map((t) => h('li', {}, t)));
}

for (const r of document.querySelectorAll('input[name=schedule]')) {
  r.addEventListener('change', async () => {
    await chrome.storage.local.set({ settings: { ...settings(), schedule: r.value } });
    toast(r.value === 'off' ? '자동 확인을 껐습니다.' : '자동 확인 주기를 바꿨습니다.');
  });
}

$('s-dates-save').addEventListener('click', async () => {
  const term = $('s-term').value;
  if (!term) {
    toast('9기 시작일을 넣어 주세요.');
    return;
  }
  await chrome.storage.local.set({ settings: { ...settings(), termStart: term, yearStart: $('s-year').value } });
  toast('누계 기준일을 저장했습니다. 당원현황 표에 바로 반영됩니다.');
});

$('s-ledger-out').addEventListener('click', () => {
  const ws = XLSX.utils.aoa_to_sheet(core.ledgerToAoa(store.ledger || core.seedLedger()));
  ws['!cols'] = core.LEDGER_COLS.map((c, i) => ({ wch: i === 6 ? 24 : 12 }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, '당원');
  XLSX.writeFile(wb, `당원현황_누계_${today()}.xlsx`);
  toast('장부를 내려받았습니다.');
});

let pendingLedger = null;
$('s-ledger-in').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    // 날짜는 글자로 읽는다(날짜 객체는 시간대 때문에 하루 밀릴 수 있음)
    const wb = XLSX.read(await file.arrayBuffer(), { type: 'array', dateNF: 'yyyy-mm-dd' });
    const ws = wb.Sheets['당원'] || wb.Sheets[wb.SheetNames[0]];
    const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false, dateNF: 'yyyy-mm-dd', defval: null });
    const r = core.ledgerFromAoa(aoa);
    pendingLedger = r.ledger;
    $('s-ledger-msg').textContent = `"${file.name}": 기록일 ${r.dates.length}개(${r.dates[0]} ~ ${r.dates.at(-1)}), ${r.ledger.length}줄을 읽었습니다.` +
      (r.skipped ? ` 날짜나 지역이 비어 건너뛴 줄 ${r.skipped}개가 있습니다.` : '') +
      ' 지금 장부를 통째로 이 파일 내용으로 바꿉니다.';
    $('s-ledger-confirm').hidden = false;
  } catch (err) {
    pendingLedger = null;
    $('s-ledger-confirm').hidden = true;
    toast(`장부를 읽지 못했습니다: ${err.message}`);
  }
});
$('s-ledger-apply').addEventListener('click', async () => {
  if (!pendingLedger) return;
  await chrome.storage.local.set({ ledger: pendingLedger });
  pendingLedger = null;
  $('s-ledger-confirm').hidden = true;
  toast('장부를 바꿨습니다. 당원현황 표에 바로 반영됩니다.');
});
$('s-ledger-cancel').addEventListener('click', () => {
  pendingLedger = null;
  $('s-ledger-confirm').hidden = true;
});

$('s-reset').addEventListener('click', () => ($('s-reset-confirm').hidden = false));
$('s-reset-no').addEventListener('click', () => ($('s-reset-confirm').hidden = true));
$('s-reset-yes').addEventListener('click', async () => {
  $('s-reset-confirm').hidden = true;
  await chrome.runtime.sendMessage({ type: 'reset' });
  toast('모든 자료를 지웠습니다.');
});

// ------------------------------------------------------------------ 시작

async function renderAll() {
  await reload();
  renderTop();
  renderLapsed();
  renderMembers();
  renderMembersMore();
  renderFee();
  renderFeeMore();
  renderSettings();
}

let pending = null;
chrome.storage.onChanged.addListener((_changes, area) => {
  if (area !== 'local') return;
  clearTimeout(pending);
  pending = setTimeout(renderAll, 50); // 여러 칸이 한꺼번에 바뀌면 한 번만 다시 그림
});

let first = 'lapsed';
try {
  first = TABS.includes(localStorage.getItem('tab')) ? localStorage.getItem('tab') : 'lapsed';
} catch {
  /* 기본 탭 */
}
showTab(first);
renderAll();

// ------------------------------------------------------------------ 출발점 만들기(처음 한 번)
// 9기 시작일·올해 시작일의 전날 끝 숫자를 사이트 이동내역으로 거꾸로 계산해 장부에 넣는다.

let yearPlan = null; // { points, events } — 화면에만 잠시, 저장하지 않음
const YEAR_NOTE = '이동내역으로 거꾸로 계산';

function dayShift(date, days) {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function yearError(text) {
  $('y-error').textContent = text;
  $('y-error').hidden = !text;
}

// 출발점: 9기 시작일과 올해 시작일(오늘 이전인 것만), 각 전날 끝 기준
function startPoints() {
  const s = settings();
  const starts = [
    { label: '9기 시작', start: s.termStart },
    { label: '올해 시작', start: s.yearStart || `${today().slice(0, 4)}-01-01` },
  ].filter((x) => x.start && x.start <= today());
  const seen = new Set();
  return starts.map((x) => ({ ...x, date: dayShift(x.start, -1) })).filter((x) => !seen.has(x.date) && seen.add(x.date));
}

$('y-run').addEventListener('click', async () => {
  yearError('');
  const pts = startPoints();
  if (!pts.length) {
    yearError('9기 시작일과 올해 시작일이 비어 있거나 오늘보다 뒤입니다. 위 "누계 기준일"을 확인해 주세요.');
    return;
  }
  if (!store.members || store.members.date !== today()) {
    yearError('먼저 위의 [지금 확인]을 눌러 오늘 당원 명단을 받은 뒤 다시 눌러 주세요.');
    return;
  }
  const btn = $('y-run');
  btn.disabled = true;
  btn.textContent = '읽는 중… (1~2분)';
  $('y-result').hidden = true;
  yearPlan = null;
  try {
    // 사이트가 '요청일'로 거를 수도 있어 6개월 앞부터 넉넉히 읽고, 계산은 처리일(승인일)로 한다
    const earliest = pts.map((p) => p.start).sort()[0];
    const got = await chrome.runtime.sendMessage({ type: 'history', from: dayShift(earliest, -183), to: today() });
    if (!got || got.error) {
      yearError(`읽지 못했습니다: ${got ? got.error : '알 수 없는 오류'} 당원관리 시스템에 로그인했는지 확인한 뒤 다시 눌러 주세요.`);
      return;
    }
    showYearPlan(pts, got.lists);
  } catch (e) {
    yearError(`읽지 못했습니다: ${e.message} 다시 눌러 주세요. 계속 안 되면 이 문구를 담당자에게 알려 주세요.`);
  } finally {
    btn.disabled = false;
    btn.textContent = '출발점 만들기';
  }
});

function showYearPlan(pts, lists) {
  const nowDate = store.members.date;
  const nowCounts = core.regionCounts(store.members.rows);
  // 지역 목록은 오늘 당원 명단에서(다른 시도에서도 쓸 수 있게). 목록에 없는 지역은 다른 시도로 본다.
  const regions = Object.keys(nowCounts).filter((r) => r !== core.NO_REGION);
  const { events, diag } = core.historyEvents(lists, regions);
  const ledger = store.ledger || [];
  const stop = []; // 넣을 수 없는 이유
  const warn = []; // 넣을 수는 있지만 확인이 필요한 것
  const info = []; // 알려만 줌

  // 1. 점검
  const items = [];
  for (const src of core.HISTORY_SOURCES) {
    const d = diag[src.key];
    const l = lists[src.key] || {};
    if (d.missing.length) {
      stop.push(`${d.label} 표를 찾지 못했습니다.`);
      items.push(`${d.label}: 표를 찾지 못했습니다(필요한 칸: ${d.missing.join(', ')}). 화면에 있던 칸: ${(l.headers || []).join(', ') || '없음'}`);
      continue;
    }
    if (d.truncated) stop.push(`${d.label}을(를) 끝까지 읽지 못했습니다(로그인이 풀렸거나 쪽이 너무 많음). 로그인을 확인하고 다시 눌러 주세요.`);
    const ok = Object.entries(d.okValues).map(([k, v]) => `${k} ${v}`).join(', ');
    let t = `${d.label}: ${d.rows}건 읽음(${l.pages || 0}쪽) → 처리된 것 ${d.counted}건` +
      (d.counted ? ` (처리일 ${d.first} ~ ${d.last})` : '') +
      ` · 처리 상태: ${ok || '없음'}` +
      (d.notDone ? ` · 처리 안 된 것 ${d.notDone}건 뺌` : '') +
      (d.noDate ? ` · 처리일 없는 것 ${d.noDate}건 뺌` : '') +
      (d.dup ? ` · 같은 이동 두 번 나온 것 ${d.dup}건 뺌` : '');
    if (Object.keys(d.kinds).length) t += ` · 구분: ${Object.entries(d.kinds).map(([k, v]) => `${k} ${v}`).join(', ')}`;
    const other = Object.entries(d.otherRegions);
    if (other.length) t += ` · 이 시도 지역위 목록에 없는 지역: ${other.map(([k, v]) => `${k} ${v}`).join(', ')}`;
    items.push(t);
    const unk = Object.entries(d.unknownOk);
    if (unk.length) warn.push(`${d.label}: 처리 상태 "${unk.map(([k, v]) => `${k}(${v}건)`).join(', ')}"가 끝난 것인지 몰라 세지 않았습니다.`);
    if (src.key !== 'move' && other.length) warn.push(`${d.label}: 지역 이름 "${other.map(([k]) => k).join(', ')}"을(를) 오늘 명단에서 찾지 못해 그 건은 계산에서 빠졌습니다.`);
  }
  $('y-diag').replaceChildren(...items.map((t) => h('li', {}, t)));
  const todayCnt = events.filter((e) => e.date === nowDate).length;
  if (todayCnt) warn.push(`오늘(${nowDate}) 처리된 건이 ${todayCnt}개 있습니다. [지금 확인]으로 명단을 받은 시각보다 뒤에 처리됐다면 지역별로 1~2명 어긋날 수 있습니다.`);

  // 2. 검증: 장부에 이미 있는 날짜(가장 이른 출발점 뒤, 오늘 전, 이 기능이 넣은 줄 제외)와 비교
  const first = pts.map((p) => p.date).sort()[0];
  const checkDates = core.ledgerDates(ledger.filter((r) => r.note !== YEAR_NOTE)).filter((d) => d > first && d < nowDate);
  const blocks = [];
  for (const d of checkDates) {
    const cmp = core.compareCounts(ledger, d, core.countsAt({ nowCounts, nowDate, events, target: d }));
    if (!cmp) continue;
    const table = h('table', { class: 'report' });
    drawTable(table, [['지역', '장부', '계산', '차이']], [...cmp.lines, cmp.total].map((x) => [x.region, core.fmtNum(x.ledger), core.fmtNum(x.calc), core.fmtSigned(x.diff)]));
    const diffRegions = cmp.lines.filter((x) => x.diff).length;
    if (diffRegions || cmp.total.diff) warn.push(`검증: ${d} 장부 숫자와 계산이 다릅니다(총계 차이 ${core.fmtSigned(cmp.total.diff)}명, 차이 나는 지역 ${diffRegions}곳).`);
    blocks.push(h('details', {},
      h('summary', {}, `${d}: 장부 ${core.fmtNum(cmp.total.ledger)}명 / 계산 ${core.fmtNum(cmp.total.calc)}명 / 차이 ${core.fmtSigned(cmp.total.diff)}명` + (diffRegions ? ` (차이 나는 지역 ${diffRegions}곳)` : ' (모든 지역 같음)')),
      h('div', { class: 'table-wrap' }, table)));
  }
  if (!blocks.length) info.push('이 컴퓨터 장부에는 비교할 예전 기록이 없어 검증은 건너뜁니다(처음 설치하면 보통 그렇습니다).');
  $('y-check').replaceChildren(...(blocks.length ? blocks : [h('p', { class: 'sub' }, '비교할 장부 기록이 없습니다.')]));

  // 3. 계산된 출발점(장부에 이미 직접 넣은 숫자가 있는 날은 그대로 둠)
  const kept = pts.filter((p) => ledger.some((r) => r.date === p.date && r.note !== YEAR_NOTE));
  for (const p of kept) info.push(`${p.label}(${p.date}) 숫자는 장부에 이미 있어(운영위 보고서 등) 그대로 둡니다.`);
  const make = pts.filter((p) => !kept.includes(p)).map((p) => ({ ...p, counts: core.countsAt({ nowCounts, nowDate, events, target: p.date }) }));
  const allRegions = core.regionSort([...new Set(make.flatMap((p) => Object.keys(p.counts)))].filter((r) => r !== core.NO_REGION));
  const head = ['지역', ...make.map((p) => `${p.label}(${p.date} 끝)`)];
  const body = allRegions.map((reg) => [reg, ...make.map((p) => core.fmtNum(p.counts[reg] ?? 0))]);
  body.push([core.TOTAL, ...make.map((p) => core.fmtNum(allRegions.reduce((s, r) => s + (p.counts[r] ?? 0), 0)))]);
  drawTable($('y-calc'), [head], make.length ? body : [['넣을 출발점이 없습니다']]);
  $('y-calc-title').textContent = make.length
    ? '각 시작일 전날 하루가 끝났을 때의 당원 수입니다. 출발점 사이 입당·탈당·전입·전출도 함께 넣습니다.'
    : '';
  for (const p of make) {
    const neg = allRegions.filter((r) => (p.counts[r] ?? 0) < 0);
    if (neg.length) warn.push(`${p.label} 계산 결과가 0보다 작은 지역이 있습니다(${neg.join(', ')}). 계산이 틀렸을 가능성이 큽니다.`);
  }
  if (!make.length) stop.push('넣을 출발점이 없습니다(이미 장부에 있음).');
  const older = core.ledgerDates(ledger).filter((d) => d < first);
  if (older.length) warn.push(`장부에 ${first}보다 앞선 기록(${older.at(-1)})이 있습니다. 누계의 입당·탈당이 실제보다 크게 나올 수 있습니다.`);

  $('y-warn').replaceChildren(...[
    ...stop.map((t) => h('li', { class: 'error' }, `넣을 수 없음: ${t}`)),
    ...warn.map((t) => h('li', {}, `주의: ${t}`)),
    ...info.map((t) => h('li', { class: 'sub' }, `안내: ${t}`)),
  ]);
  $('y-msg').textContent = stop.length
    ? '위 문제 때문에 장부에 넣을 수 없습니다. 이 화면 내용을 담당자에게 알려 주세요.'
    : `[장부에 넣기]를 누르면 ${make.map((p) => p.date).join(', ')} 줄을 장부에 넣고, 비어 있던 입당·탈당·전입·전출을 채웁니다. 이미 숫자가 있는 칸은 바꾸지 않습니다.`;
  $('y-ok').checked = false;
  $('y-ok-label').hidden = Boolean(stop.length) || !warn.length;
  $('y-apply').disabled = Boolean(stop.length) || warn.length > 0;
  yearPlan = stop.length ? null : { points: make.map(({ date, counts }) => ({ date, counts })), events };
  $('y-result').hidden = false;
}

$('y-ok').addEventListener('change', () => {
  $('y-apply').disabled = !yearPlan || !$('y-ok').checked;
});

$('y-apply').addEventListener('click', async () => {
  if (!yearPlan) return;
  try {
    const ledger = (await chrome.storage.local.get('ledger')).ledger || [];
    const r = core.addStartPoints({ ledger, points: yearPlan.points, events: yearPlan.events, note: YEAR_NOTE });
    await chrome.storage.local.set({ ledger: r.ledger });
    yearPlan = null;
    $('y-result').hidden = true;
    toast(`출발점을 장부에 넣었습니다(${r.done.map((x) => x.date).join(', ')}). 당원현황 표의 9기 누계·올해 누계에 반영됩니다.`);
  } catch (e) {
    yearError(`장부에 넣지 못했습니다: ${e.message}`);
  }
});

// ------------------------------------------------------------------ 당원현황 더 보기(작은 탭)

// 작은 탭: 탭 줄(nav.subtabs)마다 따로 바뀐다. 마지막으로 본 작은 탭을 기억(이 브라우저에만).
function showSub(nav, name) {
  for (const b of nav.querySelectorAll('button')) {
    b.setAttribute('aria-pressed', String(b.dataset.sub === name));
    $(b.dataset.sub).hidden = b.dataset.sub !== name;
  }
  try {
    localStorage.setItem(`sub:${nav.id || nav.closest('section').id}`, name);
  } catch {
    /* 저장 못 해도 괜찮음 */
  }
}
for (const nav of document.querySelectorAll('nav.subtabs')) {
  for (const b of nav.querySelectorAll('button')) b.addEventListener('click', () => showSub(nav, b.dataset.sub));
  try {
    const last = localStorage.getItem(`sub:${nav.id || nav.closest('section').id}`);
    if ([...nav.querySelectorAll('button')].some((b) => b.dataset.sub === last)) showSub(nav, last);
  } catch {
    /* 기본 첫 탭 */
  }
}

function memberError(text) {
  $('m-error').textContent = text;
  $('m-error').hidden = !text;
}

// 이동내역: 같은 화면에서는 한 번 읽은 것을 다시 쓴다(이름이 들어 있어 저장하지 않음)
let histCache = null; // { from, lists }
async function getHistory(fromDate) {
  const fetchFrom = dayShift(fromDate, -183);
  if (histCache && histCache.from <= fetchFrom && histCache.to === today()) return histCache.lists;
  const got = await chrome.runtime.sendMessage({ type: 'history', from: fetchFrom, to: today() });
  if (!got || got.error) throw new Error(got ? got.error : '알 수 없는 오류');
  histCache = { from: fetchFrom, to: today(), lists: got.lists };
  return got.lists;
}

// 이동내역을 읽어 계산 재료를 만든다. 끝까지 못 읽었거나 표를 못 찾으면 멈춘다.
async function historyBasis(fromDate) {
  if (!store.members) throw new Error('먼저 위의 [지금 확인]을 눌러 당원 명단을 받아 주세요.');
  const lists = await getHistory(fromDate);
  const nowCounts = core.regionCounts(store.members.rows);
  const regions = Object.keys(nowCounts).filter((r) => r !== core.NO_REGION);
  const { events, diag } = core.historyEvents(lists, regions);
  const bad = Object.values(diag).filter((d) => d.missing.length || d.truncated).map((d) => d.label);
  if (bad.length) throw new Error(`${bad.join(', ')}을(를) 끝까지 읽지 못했습니다. 로그인을 확인하고 다시 눌러 주세요.`);
  const unk = Object.values(diag).flatMap((d) => Object.entries(d.unknownOk).map(([k, v]) => `${d.label} "${k}" ${v}건`));
  const caution = unk.length ? `주의: 처리 상태를 몰라 뺀 기록이 있습니다(${unk.join(', ')}).` : '';
  return { nowCounts, nowDate: store.members.date, events, caution };
}

async function busy(btn, label, fn) {
  memberError('');
  const old = btn.textContent;
  btn.disabled = true;
  btn.textContent = label;
  try {
    await fn();
  } catch (e) {
    memberError(`${e.message}`);
  } finally {
    btn.disabled = false;
    btn.textContent = old;
  }
}

function renderMembersMore() {
  renderTrend();
  renderRights();
  const s = settings();
  if (!$('p-from').value) $('p-from').value = s.yearStart || `${today().slice(0, 4)}-01-01`;
  if (!$('p-to').value) $('p-to').value = today();
  if (!$('v-to').value) $('v-to').value = today();
  if (!$('v-from').value) {
    const cmp = $('m-compare').value;
    $('v-from').value = cmp ? dayShift(cmp, 1) : `${today().slice(0, 7)}-01`;
  }
}

// ---- 흐름 그래프

function lineChart(points) {
  const W = 720, H = 260, L = 56, R = 16, T = 24, B = 34;
  const vals = points.map((p) => p.value);
  let lo = Math.min(...vals), hi = Math.max(...vals);
  if (hi === lo) { hi += 1; lo -= 1; }
  const pad = (hi - lo) * 0.15;
  lo -= pad; hi += pad;
  const x = (i) => L + (points.length === 1 ? 0 : (i * (W - L - R)) / (points.length - 1));
  const y = (v) => T + ((hi - v) * (H - T - B)) / (hi - lo);
  const ns = 'http://www.w3.org/2000/svg';
  const el = (tag, attrs, text) => {
    const e = document.createElementNS(ns, tag);
    for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
    if (text != null) e.textContent = text;
    return e;
  };
  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': '달마다 당원 수' });
  svg.append(el('line', { class: 'axis', x1: L, y1: H - B, x2: W - R, y2: H - B }));
  svg.append(el('polyline', { class: 'line', points: points.map((p, i) => `${x(i)},${y(p.value)}`).join(' ') }));
  points.forEach((p, i) => {
    svg.append(el('circle', { class: 'dot', cx: x(i), cy: y(p.value), r: 4 }));
    svg.append(el('text', { class: 'val', x: x(i), y: y(p.value) - 9, 'text-anchor': 'middle' }, core.fmtNum(p.value)));
    svg.append(el('text', { x: x(i), y: H - 12, 'text-anchor': 'middle' }, p.label));
  });
  return svg;
}

function renderTrend() {
  const tr = store.trend;
  const sel = $('t-region');
  if (!tr) {
    $('t-title').textContent = '아직 계산하지 않았습니다. [지난 12개월 다시 계산]을 누르면 사이트 이동내역으로 달마다 말일 당원 수를 계산합니다(1~2분).';
    $('t-chart').replaceChildren();
    $('t-table').replaceChildren();
    return;
  }
  const regions = core.regionSort([...new Set(tr.points.flatMap((p) => Object.keys(p.counts)))].filter((r) => r !== core.NO_REGION));
  const keep = sel.value;
  sel.replaceChildren(h('option', { value: '' }, '전체'), ...regions.map((r) => h('option', { value: r }, r)));
  if (regions.includes(keep)) sel.value = keep;
  const reg = sel.value;
  const val = (p) => (reg ? p.counts[reg] ?? 0 : core.totalOf(p.counts));
  const pts = tr.points.map((p) => ({ label: `${Number(p.month.slice(5))}월`, value: val(p) }));
  $('t-chart').replaceChildren(lineChart(pts));
  $('t-title').textContent = `${reg || '전체'} · 달마다 말일 당원 수(이번 달은 ${tr.points.at(-1).date} 기준) · ${tr.made} 계산` + (tr.caution ? ` · ${tr.caution}` : '');
  const body = tr.points.map((p, i) => [p.month, core.fmtNum(val(p)), i ? core.fmtSigned(val(p) - val(tr.points[i - 1])) : '-']);
  drawTable($('t-table'), [['달', '당원수', '전달 대비']], body, { total: false });
}
$('t-region').addEventListener('change', renderTrend);
$('t-run').addEventListener('click', () => busy($('t-run'), '계산 중… (1~2분)', async () => {
  const first = `${core.monthAdd(today().slice(0, 7), -11)}-01`;
  const b = await historyBasis(first);
  const points = core.monthEnds({ nowCounts: b.nowCounts, nowDate: b.nowDate, events: b.events, months: 12 });
  // 저장하는 것은 달별·지역별 인원 숫자뿐
  await chrome.storage.local.set({ trend: { made: today(), caution: b.caution, points } });
}));

// ---- 입당·탈당 명단

let movesView = null;
$('v-run').addEventListener('click', () => busy($('v-run'), '읽는 중… (1~2분)', async () => {
  const from = $('v-from').value;
  let to = $('v-to').value;
  if (!from || !to || from > to) throw new Error('시작일과 끝일을 확인해 주세요.');
  const b = await historyBasis(from);
  if (to > today()) to = today();
  const m = core.movementList(b.events, from, to);
  const table = (head, rows) => {
    const t = h('table', { class: 'report list' });
    drawTable(t, [head], rows.length ? rows : [['없음']], { total: false });
    return h('div', { class: 'table-wrap' }, t);
  };
  const insRows = m.ins.map((x) => [x.region, x.name, x.kind, x.date]);
  const outRows = m.outs.map((x) => [x.region, x.name, x.kind, x.date]);
  const mvRows = m.moves.map((x) => [x.name, x.from, x.to, x.kind, x.date]);
  $('v-title').textContent = `${from} ~ ${to} · 입당·복당 ${m.ins.length}명 · 탈당 ${m.outs.length}명 · 지역 이동 ${m.moves.length}건` + (b.caution ? ` · ${b.caution}` : '');
  $('v-body').replaceChildren(h('div', { class: 'moves' },
    h('h3', {}, `입당·복당 ${m.ins.length}명`), table(['지역', '이름', '구분', '처리일'], insRows),
    h('h3', {}, `탈당 ${m.outs.length}명`), table(['지역', '이름', '구분', '처리일'], outRows),
    h('h3', {}, `지역 이동 ${m.moves.length}건`), table(['이름', '기존 지역', '옮긴 지역', '구분', '처리일'], mvRows)));
  movesView = { head: [['구분', '지역', '이름', '처리일', '비고']], body: [
    ...m.ins.map((x) => [x.kind, x.region, x.name, x.date, '']),
    ...m.outs.map((x) => [x.kind, x.region, x.name, x.date, '']),
    ...m.moves.map((x) => [x.kind, x.to, x.name, x.date, `${x.from} → ${x.to}`]),
  ] };
  $('v-copy').disabled = false;
}));
$('v-copy').addEventListener('click', () => movesView && copyTable(movesView.head, movesView.body, ''));

// ---- 당권자 비율

function renderRights() {
  const ledger = store.ledger || [];
  const dates = core.ledgerDates(ledger);
  const date = dates.at(-1);
  if (!date) {
    $('r-title').textContent = '아직 기록이 없습니다. [지금 확인]을 눌러 주세요.';
    $('r-table').replaceChildren();
    return;
  }
  let cmp = $('m-compare').value || null;
  // 비교일에 당권자 수가 없으면(출발점 등) 당권자 수가 있는 그 전 기록으로
  const hasRights = (d) => ledger.some((r) => r.date === d && r.region === core.TOTAL && r.rights != null);
  if (cmp && !hasRights(cmp)) cmp = [...dates].reverse().find((d) => d < date && d <= cmp && hasRights(d)) || null;
  const rr = core.rightsRatio(ledger, date, cmp);
  const t = core.rightsRatioTable(rr);
  drawTable($('r-table'), [t.head], t.body);
  $('r-title').textContent = `${date} 기록 기준` + (cmp ? ` · ${cmp} 기록과 비교` : ' · 비교할 당권자 기록이 없습니다');
}

// ---- 기간 누계

let periodView = null;
let periodBasis = null; // 마지막 계산 재료(화면에만, 저장 안 함)

function renderPeriod() {
  if (!periodBasis) return;
  const { b, from, to, note } = periodBasis;
  const view = $('p-view').value;
  const monthly = view === 'month';
  const matrix = view === 'matrix';
  $('p-region-label').hidden = !monthly;
  $('p-metric-label').hidden = !matrix;
  if (!$('p-metric').options.length) $('p-metric').replaceChildren(...Object.entries(core.MATRIX_METRICS).map(([k, v]) => h('option', { value: k }, v)));
  const regions = core.regionSort(Object.keys(b.nowCounts).filter((r) => r !== core.NO_REGION));
  const sel = $('p-region');
  const keep = sel.value;
  sel.replaceChildren(h('option', { value: '' }, '전체'), ...regions.map((r) => h('option', { value: r }, r)));
  if (regions.includes(keep)) sel.value = keep;
  const args = { nowCounts: b.nowCounts, nowDate: b.nowDate, events: b.events, from, to };
  let t;
  let title;
  const metric = $('p-metric').value;
  if (matrix) {
    t = core.periodMatrixTable(core.periodMatrix({ ...args, metric }));
    title = `당원 지역×월 ${core.MATRIX_METRICS[metric]} (${from} ~ ${to})`;
  } else if (monthly) {
    t = core.periodMonthlyTable(core.periodMonthly({ ...args, region: sel.value }));
    title = `당원 월별 현황 ${sel.value || '전체'} (${from} ~ ${to})`;
  } else {
    t = core.periodSummaryTable(core.periodSummary(args));
    title = `당원 기간 누계 (${from} ~ ${to})`;
  }
  drawTable($('p-table'), [t.head], t.body, { totals: matrix && metric === 'end' ? 2 : 1 });
  const what = matrix ? ` · 지역×월 ${core.MATRIX_METRICS[metric]}` : monthly ? ` · ${sel.value || '전체'} 월별` : ' · 지역별';
  $('p-title').textContent = `${from} ~ ${to}${note}${what}` + (b.caution ? ` · ${b.caution}` : '');
  const notes = ['사이트 이동내역(승인·복당·탈당·지역 변경)으로 거꾸로 계산한 값입니다.'];
  if (matrix && metric === 'end') notes.push('말일 당원수: 각 달 마지막 날(끝일이 그 달 안이면 끝일) 밤 기준.');
  periodView = { head: [t.head], body: t.body, notes, title, from, to, view, region: sel.value, metric };
  $('p-copy').disabled = false;
  $('p-xlsx').disabled = false;
}
$('p-view').addEventListener('change', renderPeriod);
$('p-region').addEventListener('change', renderPeriod);
$('p-metric').addEventListener('change', renderPeriod);

$('p-run').addEventListener('click', () => busy($('p-run'), '계산 중… (1~2분)', async () => {
  const from = $('p-from').value;
  let to = $('p-to').value;
  if (!from || !to || from > to) throw new Error('시작일과 끝일을 확인해 주세요.');
  const b = await historyBasis(from);
  let note = '';
  if (to > b.nowDate) {
    to = b.nowDate;
    note = ` · 끝일은 마지막 확인일(${b.nowDate})까지만 셉니다`;
  }
  periodBasis = { b, from, to, note };
  renderPeriod();
}));
$('p-copy').addEventListener('click', () => periodView && copyTable(periodView.head, periodView.body, ''));
$('p-xlsx').addEventListener('click', () => periodView && saveTableXlsx({ ...periodView, sheet: { month: '월별 현황', matrix: '지역×월' }[periodView.view] || '기간 누계', file: periodView.view === 'matrix' ? `당원_지역x월_${core.MATRIX_METRICS[periodView.metric]}_${periodView.from}_${periodView.to}.xlsx` : periodView.view === 'month' ? `당원_월별_${periodView.region || '전체'}_${periodView.from}_${periodView.to}.xlsx` : `당원_기간누계_${periodView.from}_${periodView.to}.xlsx` }));

// ------------------------------------------------------------------ 당비현황 더 보기(작은 탭)

// 고를 수 있는 달: 다시 받을 수 있는 지난 12개월만. 처음엔 지난달(이번 달은 아직 진행 중).
function fillMonths(sel, months) {
  const cur = core.monthOf(today());
  const ok = months.filter((m) => m >= core.monthAdd(cur, -(core.FEE_KEEP_MONTHS - 1)));
  const keep = sel.value;
  sel.replaceChildren(...ok.map((m) => h('option', { value: m }, core.monthLabel(m).replace('분', '') + (m === cur ? ' (진행 중)' : ''))));
  if (ok.includes(keep)) sel.value = keep;
  else if (ok.includes(core.monthAdd(cur, -1))) sel.value = core.monthAdd(cur, -1);
}

const feeViews = {}; // 작은 탭별 지금 보이는 표(복사·엑셀용)
function feeButtons(key, name) {
  $(`${key}-copy`).addEventListener('click', () => feeViews[key] && copyTable(feeViews[key].head, feeViews[key].body, ''));
  $(`${key}-xlsx`).addEventListener('click', () => feeViews[key] && saveTableXlsx({ ...feeViews[key], sheet: name, file: `${feeViews[key].file}.xlsx` }));
}

function renderFeeMore() {
  const fee = store.fee || {};
  const special = store.special || {};
  const months = Object.keys(fee).sort().reverse();
  if (!months.length) return;
  renderFeeTrend(fee, special);
  fillMonths($('fr-month'), months);
  renderPayRate(fee, special);
  const years = [...new Set(months.map((m) => m.slice(0, 4)))];
  const ys = $('fy-year');
  const keepY = ys.value;
  ys.replaceChildren(...years.map((y) => h('option', { value: y }, `${y}년`)));
  if (years.includes(keepY)) ys.value = keepY;
  renderFeeYear(fee, special);
  fillMonths($('fs-month'), months);
  renderSpDetail(fee, special);
}

// ---- 월별 추이
function renderFeeTrend(fee = store.fee || {}, special = store.special || {}) {
  const regions = core.regionSort([...new Set(Object.values(fee).flatMap((f) => f.rows.map((r) => r.region)))].filter((r) => r !== core.NO_REGION));
  const sel = $('ft-region');
  const keep = sel.value;
  sel.replaceChildren(h('option', { value: '' }, '전체'), ...regions.map((r) => h('option', { value: r }, r)));
  if (regions.includes(keep)) sel.value = keep;
  const tr = core.feeTrend({ fee, special, region: sel.value, cur: core.monthOf(today()), exclude: feeExclude() });
  const what = $('ft-what').value;
  const label = { payers: '납부자', amount: '당비', spAmount: '특별당비' }[what];
  const pts = tr.rows.filter((r) => !r.missing).map((r) => ({ label: `${Number(r.month.slice(5))}월`, value: r[what] }));
  $('ft-chart').replaceChildren(...(pts.length ? [lineChart(pts)] : []));
  const missing = tr.rows.filter((r) => r.missing).length;
  $('ft-title').textContent = `${sel.value || '전체'} · ${label}${feeExclude().length ? '(평생당비 제외)' : ''} · 지난 12개월(처리분 기준, 이번 달은 아직 진행 중)` + (missing ? ` · 자료 없는 달 ${missing}개 — [지금 확인]을 누르면 채워집니다` : '');
  const t = core.feeTrendTable(tr);
  drawTable($('ft-table'), [t.head], t.body, { total: false });
  feeViews.ft = { head: [t.head], body: t.body, notes: ['그달에 처리된 당비 기준(밀린 달을 함께 내도 그 처리 달에 셈).', ...exNote()], title: `당비 월별 추이 ${sel.value || '전체'}`, file: `당비_월별추이_${sel.value || '전체'}` };
}
$('ft-region').addEventListener('change', () => renderFeeTrend());
$('ft-what').addEventListener('change', () => renderFeeTrend());
feeButtons('ft', '월별 추이');

// ---- 지역별 납부율
function renderPayRate(fee = store.fee || {}, special = store.special || {}) {
  const month = $('fr-month').value;
  const pr = month ? core.payRate({ fee, special, month, ledger: store.ledger || [] }) : null;
  if (!pr) { $('fr-table').replaceChildren(); $('fr-title').textContent = ''; return; }
  const t = core.payRateTable(pr);
  drawTable($('fr-table'), [t.head], t.body);
  $('fr-title').textContent = `${core.monthLabel(month).replace('분', '')} 처리분 · 당원수·당권자는 ${pr.base || '장부 기록 없음'} 기록 기준`;
  feeViews.fr = { head: [t.head], body: t.body, notes: [`당원수·당권자: ${pr.base || '-'} 기록 기준.`], title: `지역별 당비 납부율 (${month})`, file: `당비_납부율_${month}` };
}
$('fr-month').addEventListener('change', () => renderPayRate());
feeButtons('fr', '납부율');

// ---- 올해 누계
function renderFeeYear(fee = store.fee || {}, special = store.special || {}) {
  const year = $('fy-year').value;
  if (!year) return;
  const cur = core.monthOf(today());
  const upto = cur.startsWith(year) ? cur : `${year}-12`;
  const fy = core.feeYear({ fee, special, year, upto, exclude: feeExclude() });
  const t = core.feeYearTable(fy);
  drawTable($('fy-table'), [t.head], t.body);
  $('fy-title').textContent = `${year}년 1월 ~ ${Number(upto.slice(5))}월 처리분${feeExclude().length ? ' · 평생당비 제외' : ''}` + (fy.missing.length ? ` · 자료 없는 달: ${fy.missing.map((m) => `${Number(m.slice(5))}월`).join(', ')} (빠진 채로 더했습니다)` : '');
  feeViews.fy = { head: [t.head], body: t.body, notes: [...(fy.missing.length ? [`자료 없는 달(${fy.missing.join(', ')})은 빠진 합계입니다.`] : []), ...exNote()], title: `당비 올해 누계 (${year}년)`, file: `당비_올해누계_${year}` };
}
$('fy-year').addEventListener('change', () => renderFeeYear());
feeButtons('fy', '올해 누계');

// ---- 특별당비 상세
function renderSpDetail(fee = store.fee || {}, special = store.special || {}) {
  const month = $('fs-month').value;
  const sd = month ? core.spDetail({ fee, special, month, exclude: feeExclude() }) : null;
  if (!sd) { $('fs-table').replaceChildren(); $('fs-title').textContent = ''; return; }
  const t = core.spDetailTable(sd);
  drawTable($('fs-table'), [t.head], t.body);
  $('fs-title').textContent = `${core.monthLabel(month).replace('분', '')} 처리분 · 종류별 건수·금액(특별당비가 있는 종류만${feeExclude().length ? ', 평생당비 제외' : ''})` +
    ` · 나눠 보기: 당비 내역의 특별당비 칸 ${core.fmtNum(sd.fromFee.n)}건 ${core.fmtNum(sd.fromFee.amt)}원 + 특당비 내역 ${core.fmtNum(sd.fromSpecial.n)}건 ${core.fmtNum(sd.fromSpecial.amt)}원` +
    (sd.overlap ? ` · 주의: 두 내역에 같은 사람·같은 금액이 ${sd.overlap}건 있습니다(겹쳐 셌을 수 있음)` : '') +
    (sd.old ? ' · 이 달은 예전 형식이라 종류를 모릅니다 — [지금 확인]을 한 번 누르면 채워집니다' : '') +
    (sd.hasSpecialFile ? '' : ' · 이 달 특당비 내역은 아직 받지 않았습니다');
  feeViews.fs = { head: [t.head], body: t.body, notes: exNote(), title: `특별당비 상세 (${month})`, file: `특별당비_상세_${month}` };
}
$('fs-month').addEventListener('change', () => renderSpDetail());
feeButtons('fs', '특별당비 상세');

$('fee-nolife').addEventListener('change', async () => {
  await chrome.storage.local.set({ settings: { ...settings(), excludeLifetime: $('fee-nolife').checked } });
  toast($('fee-nolife').checked ? '평생당비를 빼고 셉니다.' : '평생당비를 넣어 셉니다.');
});
