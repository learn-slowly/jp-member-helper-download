// 당원관리 도우미 — 계산 전부.
// 브라우저 API(chrome.*, DOM)를 쓰지 않는다. 백그라운드·화면·Node 테스트가 같이 쓴다.
// 계산 규칙의 기준은 당원관리도우미_prd.md 3절·8절이다.

// ------------------------------------------------------------------ 상수

// 보고서 표 순서(사이트 선택지 순서). 새 지역은 뒤에 가나다순으로 붙는다.
export const REGION_ORDER = [
  '거제시', '거창군', '김해시', '남해하동', '밀양시', '사천시', '산청군', '양산시',
  '의령군', '진주시', '창녕군', '창원시 마산', '창원시 성산', '창원시 의창', '창원시 진해',
  '통영고성', '함안군', '함양군', '합천군',
];
export const TOTAL = '총계';
export const NO_REGION = '(지역없음)';

export const SPECIAL_COLS = [
  '공직특별당비', '중앙당특별당비', '시도당특별당비', '지역당특별당비',
  '기타특별당비', '평생특별당비', '부채특별당비',
];

export const DEFAULT_SETTINGS = {
  schedule: 'drawdays', // drawdays(7·17·27일) | daily | weekly | off
  termStart: '2026-09-01', // 9기 시작일(2026-11-04 레고님 결정, 그 전에는 9/12)
  yearStart: '', // 비우면 그해 1월 1일
  prior: 3, // 앞선 몇 개월 동안 낸 사람을 볼지
};


// 사이트 양식이 바뀌어 필수 칸이 없을 때 쓰는 오류. 틀린 숫자를 내지 않고 멈추기 위함.
export class SiteFormatError extends Error {
  constructor(what, col) {
    super(`${what}에 '${col}' 칸이 없습니다. 사이트 양식이 바뀌었을 수 있습니다.`);
    this.name = 'SiteFormatError';
  }
}

// ------------------------------------------------------------------ 작은 도구

export function toInt(v) {
  const n = parseInt(String(v ?? '').replace(/,/g, '').trim(), 10);
  return Number.isFinite(n) ? n : 0;
}

export function regionSort(regions) {
  const set = new Set(regions);
  set.delete(TOTAL);
  const known = REGION_ORDER.filter((r) => set.has(r));
  const extra = [...set].filter((r) => !REGION_ORDER.includes(r)).sort((a, b) => a.localeCompare(b, 'ko'));
  return [...known, ...extra];
}

// '2026-10' + k개월
export function monthAdd(month, k) {
  const [y, m] = month.split('-').map(Number);
  const i = y * 12 + (m - 1) + k;
  return `${Math.floor(i / 12)}-${String((i % 12) + 1).padStart(2, '0')}`;
}

export function monthOf(dateStr) {
  return dateStr.slice(0, 7);
}

// 앞선 prior개월 + 지난달 + 이번 달. 10월이면 6·7·8·9·10월.
export function monthsNeeded(cur, prior = DEFAULT_SETTINGS.prior) {
  const out = [];
  for (let k = prior + 1; k >= 0; k--) out.push(monthAdd(cur, -k));
  return out;
}

export function monthLabel(month) {
  return `${Number(month.slice(5))}월분`;
}

// 'YYYY.MM.DD', 'YYYY/M/D' 등을 'YYYY-MM-DD'로
export function normDate(v) {
  const raw = String(v ?? '').trim();
  // 엑셀이 날짜를 숫자(1900년부터 센 날 수)로 줄 때: 2000~2099년 범위만 날짜로 본다
  if (/^\d{5}(\.\d+)?$/.test(raw)) {
    const n = Math.floor(Number(raw));
    if (n >= 36526 && n <= 73050) {
      const d = new Date(Date.UTC(1899, 11, 30) + n * 86400000);
      return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
    }
  }
  const s = raw.replace(/\s*년\s*|\s*월\s*/g, '-').replace(/\s*일.*$/, '').replace(/[./]/g, '-').replace(/-\s+/g, '-');
  const m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (!m) return s;
  return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
}

// ------------------------------------------------------------------ 사이트 파일 읽기

// 사이트 '엑셀'은 HTML 표이고 인코딩이 파일마다 다르다. UTF-8 엄격 → 실패하면 EUC-KR.
export function decodeBytes(bytes) {
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  } catch {
    return new TextDecoder('euc-kr').decode(bytes);
  }
}

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
function unescapeHtml(s) {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (all, e) => {
    if (e[0] === '#') {
      const code = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : all;
    }
    return ENTITIES[e.toLowerCase()] ?? all;
  });
}

// 첫 <tr>이 머리줄. 칸 수가 머리줄과 다른 줄('합계' 등)은 버린다.
// 서비스 워커에는 DOMParser가 없으므로 정규식으로 읽는다.
export function parseHtmlTable(text) {
  const rows = [];
  for (const tr of text.match(/<tr\b[\s\S]*?<\/tr>/gi) || []) {
    const cells = [...tr.matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)];
    rows.push(cells.map((c) => unescapeHtml(c[1].replace(/<[^>]+>/g, '')).trim()));
  }
  if (!rows.length) throw new Error('표를 찾지 못했습니다.');
  const header = rows[0];
  return { header, rows: rows.slice(1).filter((r) => r.length === header.length) };
}

function colIndex(header, what, required, optional = []) {
  const idx = {};
  for (const n of required) {
    const i = header.indexOf(n);
    if (i < 0) throw new SiteFormatError(what, n);
    idx[n] = i;
  }
  for (const n of optional) {
    const i = header.indexOf(n);
    if (i >= 0) idx[n] = i;
  }
  return idx;
}

const get = (r, idx, n) => (idx[n] === undefined ? '' : r[idx[n]] ?? '');

// ------------------------------------------------------------------ 최소 수집 정규화
// 저장하는 칸은 PRD 4.2 "최소 수집" 목록뿐. 주소·주민번호·생년월일·이메일·예금주·메모는 버린다.

export function normalizeMembers({ header, rows }) {
  const idx = colIndex(header, '당원목록', ['당원번호', '지역', '당권여부'], ['이름', '휴대전화', '승인일']);
  return rows
    .filter((r) => get(r, idx, '당원번호'))
    .map((r) => ({
      id: get(r, idx, '당원번호'),
      name: get(r, idx, '이름'),
      region: get(r, idx, '지역') || NO_REGION,
      phone: get(r, idx, '휴대전화'),
      rights: get(r, idx, '당권여부').toUpperCase() === 'Y',
      appr: normDate(get(r, idx, '승인일')).slice(0, 10),
    }));
}

// 납부구분 'Y/202608' → '2026-08'. 없으면 파일의 달.
export function duesMonth(code, fallback) {
  const m = String(code ?? '').match(/(\d{4})(\d{2})/);
  return m ? `${m[1]}-${m[2]}` : fallback;
}

export function normalizeFee({ header, rows }, fileMonth) {
  const idx = colIndex(
    header, '당비납부내역', ['당원번호', '지역', '납부구분', '당비'],
    ['이름', '휴대폰', '납부방법', '약정금액', '인출일', ...SPECIAL_COLS],
  );
  return rows
    .filter((r) => get(r, idx, '당원번호'))
    .map((r) => ({
      id: get(r, idx, '당원번호'),
      name: get(r, idx, '이름'),
      region: get(r, idx, '지역') || NO_REGION,
      phone: get(r, idx, '휴대폰'),
      method: get(r, idx, '납부방법'),
      pledge: toInt(get(r, idx, '약정금액')),
      draw: get(r, idx, '인출일'),
      dues: duesMonth(get(r, idx, '납부구분'), fileMonth),
      amt: toInt(get(r, idx, '당비')),
      sp: SPECIAL_COLS.reduce((s, c) => s + toInt(get(r, idx, c)), 0),
      spBy: spByOf(r, idx),
    }));
}

// 특별당비 종류별 금액(0이 아닌 것만)
function spByOf(r, idx) {
  const o = {};
  for (const c of SPECIAL_COLS) {
    const v = toInt(get(r, idx, c));
    if (v) o[c] = v;
  }
  return o;
}

export function normalizeSpecial({ header, rows }) {
  const idx = colIndex(header, '특당비납부내역', ['당원번호', '지역'], SPECIAL_COLS);
  return rows
    .filter((r) => get(r, idx, '당원번호'))
    .map((r) => ({
      id: get(r, idx, '당원번호'),
      region: get(r, idx, '지역') || NO_REGION,
      sp: SPECIAL_COLS.reduce((s, c) => s + toInt(get(r, idx, c)), 0),
      spBy: spByOf(r, idx),
    }));
}

// ------------------------------------------------------------------ 당비 미납자

export const KIND = {
  BOTH: '지난달·이번달 모두 미납',
  LAST: '지난달만 미납',
  CUR: '이번달만 미납',
  WAIT: '인출 대기', // 화면에만 흐리게. 숫자·알림에서 뺀다.
};
const KIND_ORDER = [KIND.BOTH, KIND.LAST, KIND.CUR, KIND.WAIT];

// 인출일이 5·15·25 같은 날짜면 숫자, 없거나 0(직접납부·카드 등)이면 null
export function drawDay(v) {
  const n = toInt(v);
  return n >= 1 && n <= 31 ? n : null;
}

// 이번 달분을 미납으로 셀 수 있는 날인가: 인출일 + 2일이 지났는가.
// 25일 인출이면 27일부터 센다. 인출일이 없으면 이번 달분으로는 판단하지 않는다.
export function curMonthDue(draw, today) {
  const d = drawDay(draw);
  if (d === null) return false;
  return Number(today.slice(8, 10)) >= d + 2;
}

// feeByMonth: { '2026-09': { rows: [normalizeFee 결과] }, ... } (파일의 달 기준)
// members: normalizeMembers 결과 (없으면 모두 "명단에 없음")
// today: 'YYYY-MM-DD'. 이번 달은 today의 달.
export function findLapsed({ feeByMonth, members, today, prior = DEFAULT_SETTINGS.prior }) {
  const cur = monthOf(today);
  const last = monthAdd(cur, -1);
  const priorMonths = [];
  for (let k = prior + 1; k >= 2; k--) priorMonths.push(monthAdd(cur, -k));
  const wanted = new Set(monthsNeeded(cur, prior));

  // 사람별로 몇 월분을 냈는지 모은다. 오래된 파일부터 읽어 최신 값으로 덮어쓴다.
  const people = new Map();
  for (const fileMonth of Object.keys(feeByMonth).sort()) {
    if (!wanted.has(fileMonth)) continue;
    for (const r of feeByMonth[fileMonth].rows) {
      if (!r.id || r.amt <= 0) continue;
      let p = people.get(r.id);
      if (!p) {
        p = { id: r.id, name: '', region: '', phone: '', method: '', pledge: 0, draw: '', paid: {} };
        people.set(r.id, p);
      }
      p.name = r.name || p.name;
      p.region = r.region || p.region;
      p.phone = r.phone || p.phone;
      p.method = r.method || p.method;
      p.pledge = r.pledge || p.pledge;
      p.draw = r.draw || p.draw; // 가장 최근 줄의 인출일
      p.paid[r.dues] = (p.paid[r.dues] || 0) + r.amt;
    }
  }

  const memberMap = new Map((members || []).map((m) => [m.id, m]));
  const out = [];
  for (const p of people.values()) {
    const priorPaid = priorMonths.filter((m) => m in p.paid).length;
    if (priorPaid === 0) continue;
    const missLast = !(last in p.paid);
    const curUnpaid = !(cur in p.paid);
    const due = curMonthDue(p.draw, today);
    const missCur = curUnpaid && due;
    const waiting = curUnpaid && !due && drawDay(p.draw) !== null;
    let kind;
    if (missLast && missCur) kind = KIND.BOTH;
    else if (missLast) kind = KIND.LAST;
    else if (missCur) kind = KIND.CUR;
    else if (waiting) kind = KIND.WAIT;
    else continue;

    const info = memberMap.get(p.id);
    const inList = Boolean(info);
    out.push({
      id: p.id,
      name: (info && info.name) || p.name,
      region: (info && info.region) || p.region || NO_REGION,
      phone: (info && info.phone) || p.phone,
      rights: info ? info.rights : null,
      inList,
      method: p.method,
      pledge: p.pledge,
      draw: drawDay(p.draw),
      paid: p.paid,
      priorPaid,
      priorAll: priorPaid === priorMonths.length,
      lastPaid: Object.keys(p.paid).sort().pop() || null,
      missLast,
      missCur,
      waiting,
      kind,
      // 미납 숫자·알림·아이콘 숫자에 넣는가: 명단에 있고, 인출 대기만 있는 사람이 아님
      counted: inList && kind !== KIND.WAIT,
    });
  }
  const rk = (r) => {
    const i = REGION_ORDER.indexOf(r);
    return i < 0 ? 99 : i;
  };
  out.sort((a, b) =>
    (a.inList === b.inList ? 0 : a.inList ? -1 : 1) ||
    rk(a.region) - rk(b.region) || a.region.localeCompare(b.region, 'ko') ||
    KIND_ORDER.indexOf(a.kind) - KIND_ORDER.indexOf(b.kind) ||
    a.name.localeCompare(b.name, 'ko'));
  return { cur, last, priorMonths, list: out, counts: countLapsed(out) };
}

export function countLapsed(list) {
  const c = { total: 0, [KIND.BOTH]: 0, [KIND.LAST]: 0, [KIND.CUR]: 0, waiting: 0, gone: 0 };
  for (const x of list) {
    if (!x.inList) c.gone += 1;
    else if (x.kind === KIND.WAIT) c.waiting += 1;
    else {
      c.total += 1;
      c[x.kind] += 1;
    }
  }
  return c;
}

// 새 미납자: 이번 달 숫자에 들어가는 사람 중 아직 알리지 않은 사람
export function newLapsed(list, notifiedIds = []) {
  const seen = new Set(notifiedIds);
  return list.filter((x) => x.counted && !seen.has(x.id));
}

// ------------------------------------------------------------------ 당비 현황

// 납부자 수는 사람 기준(같은 사람 여러 줄이어도 1명). 금액은 그 파일(그달 처리분) 합계.
// 특별당비 = 당비 파일의 특별당비 7칸 합(0보다 크면 1건) + 같은 달 특당비 파일.
// 뺄 특별당비 종류(예: 평생특별당비)를 뺀 그 줄의 특별당비
export function spOf(r, exclude = []) {
  if (!exclude.length) return r.sp;
  const cut = exclude.reduce((s, c) => s + (r.spBy?.[c] || 0), 0);
  return r.sp - cut;
}

export function feeStats(feeRows = [], specialRows = [], { exclude = [] } = {}) {
  const stats = {};
  const at = (reg) => (stats[reg] ||= { payers: 0, amount: 0, spCount: 0, spAmount: 0 });
  const payers = {};
  for (const r of feeRows) {
    const s = at(r.region);
    if (r.amt > 0) (payers[r.region] ||= new Set()).add(r.id);
    s.amount += r.amt;
    const sp = spOf(r, exclude);
    if (sp > 0) {
      s.spCount += 1;
      s.spAmount += sp;
    }
  }
  for (const [reg, ids] of Object.entries(payers)) at(reg).payers = ids.size;
  for (const r of specialRows) {
    const sp = spOf(r, exclude);
    if (sp > 0) {
      const s = at(r.region);
      s.spCount += 1;
      s.spAmount += sp;
    }
  }
  const total = { payers: 0, amount: 0, spCount: 0, spAmount: 0 };
  for (const s of Object.values(stats)) for (const k in total) total[k] += s[k];
  stats[TOTAL] = total;
  return stats;
}

// ------------------------------------------------------------------ 당원 장부와 누계

// 장부 줄: { date, region, members, rights, in, out, moveIn, moveOut, note }
// in/out이 null이면 "비교 기준 없음".
// 출발점 장부. 실제 운영위 숫자는 프로그램에 넣지 않는다(공개 배포판이라서).
// 처음 설치하면 빈 장부로 시작하고, 출발점은 설정 → [장부 가져오기]로 엑셀 파일을 넣는다.
export function seedLedger() {
  return [];
}

// seed: { members: {지역: [당원수, 당권자, 입당, 탈당]}, baseDate, baseTotal: [당원수, 당권자], reportDate }
// 운영위 보고서 표 하나로 장부 줄을 만든다(시험과 출발점 파일 만들기용).
export function buildSeedLedger(seed) {
  const rows = [];
  for (const reg of REGION_ORDER) {
    const [n, , i, o] = seed.members[reg];
    rows.push({ date: seed.baseDate, region: reg, members: n - i + o, rights: null, in: null, out: null, moveIn: 0, moveOut: 0, note: '보고서에서 역산' });
  }
  rows.push({ date: seed.baseDate, region: TOTAL, members: seed.baseTotal[0], rights: seed.baseTotal[1], in: null, out: null, moveIn: 0, moveOut: 0, note: '운영위 보고서' });
  const tot = [0, 0, 0, 0];
  for (const reg of REGION_ORDER) {
    const [n, k, i, o] = seed.members[reg];
    rows.push({ date: seed.reportDate, region: reg, members: n, rights: k, in: i, out: o, moveIn: 0, moveOut: 0, note: '운영위 보고서' });
    tot[0] += n; tot[1] += k; tot[2] += i; tot[3] += o;
  }
  rows.push({ date: seed.reportDate, region: TOTAL, members: tot[0], rights: tot[1], in: tot[2], out: tot[3], moveIn: 0, moveOut: 0, note: '운영위 보고서' });
  return rows;
}

// 명단 사본: 당원번호 → [지역, 당권자] (이름·연락처는 넣지 않는다)
export function snapshotOf(members) {
  const s = {};
  for (const m of members) s[m.id] = [m.region, m.rights];
  return s;
}

export function ledgerDates(ledger) {
  return [...new Set(ledger.map((r) => r.date))].sort();
}

// 그날 받은 당원목록으로 장부에 그날 줄을 남긴다(같은 날 줄은 덮어씀).
// prevSnapshot이 있으면 당원번호를 비교해 정확히 세고, 없으면 승인일로 추정한다.
// 돌려주는 값: { ledger(새 배열), snapshot, method, prevDate }
export function recordDay({ ledger, members, date, prevSnapshot = null, prevDate = null }) {
  const counts = {};
  const at = (reg) => (counts[reg] ||= { members: 0, rights: 0, in: 0, out: 0, moveIn: 0, moveOut: 0 });
  for (const m of members) {
    const c = at(m.region);
    c.members += 1;
    if (m.rights) c.rights += 1;
  }
  const before = ledger.filter((r) => r.date < date);
  const pd = prevDate ?? (ledgerDates(before).pop() || null);
  const prevRows = {};
  for (const r of before) if (r.date === pd) prevRows[r.region] = r;

  const snapshot = snapshotOf(members);
  let method;
  if (pd && prevSnapshot) {
    method = '당원번호 목록 비교';
    for (const [id, [reg]] of Object.entries(snapshot)) {
      const old = prevSnapshot[id];
      if (!old) at(reg).in += 1;
      else if (old[0] !== reg) {
        // 지역 이동은 입당·탈당이 아니라 전입·전출
        at(reg).moveIn += 1;
        at(old[0]).moveOut += 1;
      }
    }
    for (const [id, [reg]] of Object.entries(prevSnapshot)) if (!snapshot[id]) at(reg).out += 1;
  } else if (pd) {
    method = '승인일 기준 추정';
    for (const m of members) if (m.appr && m.appr > pd) at(m.region).in += 1;
    for (const reg of new Set([...Object.keys(counts), ...Object.keys(prevRows)])) {
      if (reg === TOTAL) continue;
      const p = prevRows[reg]?.members;
      if (p != null) at(reg).out = Math.max(0, p + at(reg).in - at(reg).members);
    }
  } else {
    method = '비교 기준 없음';
  }

  const regions = regionSort([...Object.keys(counts), ...Object.keys(prevRows)]);
  const rows = regions.map((reg) => {
    const c = at(reg);
    const note = [c.moveIn ? `전입 ${c.moveIn}` : '', c.moveOut ? `전출 ${c.moveOut}` : ''].filter(Boolean).join(', ');
    return { date, region: reg, members: c.members, rights: c.rights, in: pd ? c.in : null, out: pd ? c.out : null, moveIn: c.moveIn, moveOut: c.moveOut, note };
  });
  const sum = (k) => rows.reduce((s, r) => s + (r[k] ?? 0), 0);
  rows.push({ date, region: TOTAL, members: sum('members'), rights: sum('rights'), in: pd ? sum('in') : null, out: pd ? sum('out') : null, moveIn: sum('moveIn'), moveOut: sum('moveOut'), note: method });

  return { ledger: [...ledger.filter((r) => r.date !== date), ...rows], snapshot, method, prevDate: pd };
}

// 구간 누계: start 이전(같은 날 포함)의 마지막 기록일이 기준점.
// 그 뒤 ~ date까지 기록일들의 입당·탈당 합, 증감 = date 당원수 − 기준점 당원수.
export function periodTotals(ledger, date, start) {
  const baseDate = ledgerDates(ledger.filter((r) => r.date <= start)).pop() || null;
  if (!baseDate) return { start, baseDate: null, ok: false, ins: {}, outs: {}, delta: {} };
  const ins = {};
  const outs = {};
  for (const r of ledger) {
    if (r.date > baseDate && r.date <= date) {
      if (r.in != null) ins[r.region] = (ins[r.region] || 0) + r.in;
      if (r.out != null) outs[r.region] = (outs[r.region] || 0) + r.out;
    }
  }
  const base = {};
  const now = {};
  for (const r of ledger) {
    if (r.date === baseDate) base[r.region] = r.members;
    if (r.date === date) now[r.region] = r.members;
  }
  const delta = {};
  for (const reg of Object.keys(now)) delta[reg] = base[reg] == null ? null : now[reg] - base[reg];
  return { start, baseDate, ok: true, ins, outs, delta };
}

// 당원현황 보고표 데이터. compareDate가 없으면 date 직전 기록일과 비교.
export function memberReport({ ledger, date, compareDate = null, termStart, yearStart }) {
  const nowRows = ledger.filter((r) => r.date === date);
  if (!nowRows.length) return null;
  const dates = ledgerDates(ledger).filter((d) => d < date);
  const prevDate = compareDate && dates.includes(compareDate) ? compareDate : dates.pop() || null;
  const prev = {};
  for (const r of ledger) if (r.date === prevDate) prev[r.region] = r;
  // 직전 대비 입당·탈당 = 비교일 뒤 ~ date까지 합
  const since = prevDate ? periodTotals(ledger, date, prevDate) : null;
  const ys = yearStart || `${date.slice(0, 4)}-01-01`;
  const term = periodTotals(ledger, date, termStart || DEFAULT_SETTINGS.termStart);
  const year = periodTotals(ledger, date, ys);
  const now = {};
  for (const r of nowRows) now[r.region] = r;
  const regions = regionSort(Object.keys(now));
  const line = (reg) => ({
    region: reg,
    members: now[reg]?.members ?? null,
    rights: now[reg]?.rights ?? null,
    in: since ? since.ins[reg] ?? 0 : null,
    out: since ? since.outs[reg] ?? 0 : null,
    term: term.ok ? { in: term.ins[reg] ?? 0, out: term.outs[reg] ?? 0, delta: term.delta[reg] ?? null } : null,
    year: year.ok ? { in: year.ins[reg] ?? 0, out: year.outs[reg] ?? 0, delta: year.delta[reg] ?? null } : null,
    note: now[reg]?.note ?? '',
  });
  const t = now[TOTAL];
  const p = prev[TOTAL];
  return {
    date,
    prevDate,
    term,
    year,
    estimated: t?.note === '승인일 기준 추정',
    rows: regions.map(line),
    total: line(TOTAL),
    summary: p ? summaryLine(p.members, t.members, p.rights, t.rights) : '',
  };
}

const fmt = (n) => (n == null ? '-' : n.toLocaleString('ko-KR'));
const signed = (n) => (n > 0 ? `+${fmt(n)}` : n < 0 ? `-${fmt(-n)}` : '0');

// 예: "전체 당원수 : 1,000명 → 998명 (-2명) / 당권자수 : 300명 → 299명 (-1명)"
export function summaryLine(m0, m1, r0, r1) {
  const part = (label, a, b) =>
    a == null && b != null ? `${label} : ${fmt(b)}명` // 비교 기준 숫자가 없으면(출발점 등) 지금 숫자만
      : `${label} : ${fmt(a)}명 → ${fmt(b)}명` + (a != null && b != null ? ` (${signed(b - a)}명)` : '');
  return `${part('전체 당원수', m0, m1)} / ${part('당권자수', r0, r1)}`;
}

// ------------------------------------------------------------------ 보관 정리

// 객체 키(날짜·달) 중 최근 n개만 남긴다
export function keepLatest(obj, n) {
  const keep = Object.keys(obj || {}).sort().slice(-n);
  return Object.fromEntries(keep.map((k) => [k, obj[k]]));
}

// ------------------------------------------------------------------ 자동 확인 일정

export const DRAW_CHECK_DAYS = [7, 17, 27]; // CMS 인출(5·15·25일) 이틀 뒤

// 오늘 자동 확인을 할 차례인가. today 'YYYY-MM-DD', hour 0~23, weekday 0(일)~6(토).
// 오전 9시 이후, 그날 아직 성공하지 않았을 때만.
export function shouldAutoRun({ schedule, today, hour, weekday, lastAutoOk }) {
  if (schedule === 'off' || hour < 9 || lastAutoOk === today) return false;
  if (schedule === 'daily') return true;
  if (schedule === 'weekly') return weekday === 1;
  return DRAW_CHECK_DAYS.includes(Number(today.slice(8, 10)));
}

// 이번에 받아야 할 당비 달: 앞선 3개월 + 지난달 + 이번 달 중
// 아직 없는 달, 그리고 최근 3개월은 밀린 납부 반영을 위해 매번 새로.
// 받을 달: 미납 판단에 필요한 달 + 지난 12개월(월별 추이·올해 누계). 최근 3개월은 늘 다시 받고(밀린 납부 반영),
// 나머지는 아직 없거나 예전 형식(특별당비 종류별이 없는 것)일 때만 받는다. have = 이미 새 형식으로 가진 달.
export const FEE_KEEP_MONTHS = 12;
export function feeMonthsToFetch(cur, have = [], prior = DEFAULT_SETTINGS.prior) {
  const recent = new Set([monthAdd(cur, -2), monthAdd(cur, -1), cur]);
  const got = new Set(have);
  const want = new Set(monthsNeeded(cur, prior));
  for (let k = FEE_KEEP_MONTHS - 1; k >= 0; k--) want.add(monthAdd(cur, -k));
  return [...want].sort().filter((m) => recent.has(m) || !got.has(m));
}
// 특당비 파일: 지난 12개월. 최근 3개월은 늘 다시 받는다.
export function specialMonthsToFetch(cur, have = []) {
  const got = new Set(have);
  const out = [];
  for (let k = FEE_KEEP_MONTHS - 1; k >= 0; k--) {
    const m = monthAdd(cur, -k);
    if (k <= 2 || !got.has(m)) out.push(m);
  }
  return out;
}
// 저장된 달 중 새 형식(특별당비 종류별 있음)인 달
export const FEE_FORMAT = 2;
export function freshMonths(store = {}) {
  return Object.entries(store).filter(([, v]) => v && v.v === FEE_FORMAT).map(([m]) => m);
}

// 날짜 → 'YYYY-MM-DD' (사용자 컴퓨터 시각 기준)
export function localDate(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// ------------------------------------------------------------------ 화면·보고용 표

export const fmtNum = (n) => (n == null ? '-' : Number(n).toLocaleString('ko-KR'));
export const fmtSigned = (n) => (n == null ? '-' : n > 0 ? `+${fmtNum(n)}` : n < 0 ? `-${fmtNum(-n)}` : '0');

// 사이트 납부방법 코드 → 사용자 말. 모르는 코드는 그대로 보여준다.
const METHOD_LABEL = { CMS: 'CMS', HP: '휴대폰', CARD: '카드', DIRECT: '직접납부' };

// 미납자 한 사람을 한 줄 문장 조각으로. 이름은 화면에서 따로 굵게 쓴다.
// 예: ['당권자', '10월분 미납', '마지막 납부 9월분', 'CMS 25일 인출', '약정 10,000원', '지난 3개월 간 3회 납부', '010-…']
export function lapsedParts(x, { cur, last, prior = DEFAULT_SETTINGS.prior }) {
  const p = [];
  if (x.rights) p.push('당권자');
  const m = (mm) => Number(mm.slice(5));
  if (x.kind === KIND.BOTH) p.push(`${m(last)}·${m(cur)}월분 미납`);
  else if (x.kind === KIND.LAST) p.push(`${monthLabel(last)} 미납`);
  else if (x.kind === KIND.CUR) p.push(`${monthLabel(cur)} 미납`);
  else if (x.kind === KIND.WAIT) p.push(`${monthLabel(cur)} 인출 대기(${x.draw}일 인출, ${x.draw + 2}일부터 셈)`);
  if (x.kind === KIND.LAST && x.waiting) p.push('이번 달 인출 대기');
  p.push(x.lastPaid ? `마지막 납부 ${monthLabel(x.lastPaid)}` : '최근 납부 없음');
  const method = METHOD_LABEL[x.method] || x.method;
  if (x.draw) p.push(`${method || 'CMS'} ${x.draw}일 인출`);
  else if (method) p.push(method);
  if (x.pledge) p.push(`약정 ${fmtNum(x.pledge)}원`);
  p.push(`지난 ${prior}개월 간 ${x.priorPaid}회 납부`);
  if (x.phone) p.push(x.phone);
  return p;
}

// 필터: region(''=전체), kind(''=전체), hideContacted, priorAll, q(이름·당원번호 검색)
export function filterLapsed(list, f = {}, contacted = new Set()) {
  const q = (f.q || '').trim();
  return list.filter((x) =>
    (!f.region || x.region === f.region) &&
    (!f.kind || x.kind === f.kind) &&
    (!f.hideContacted || !contacted.has(x.id)) &&
    (!f.priorAll || x.priorAll) &&
    (!q || x.name.includes(q) || x.id.includes(q)));
}

// 미납자 엑셀용 표(첫 줄 머리)
export function lapsedAoa(list, { cur, prior = DEFAULT_SETTINGS.prior }, contacted = new Set()) {
  const months = monthsNeeded(cur, prior);
  const head = ['지역', '당원번호', '이름', '휴대폰', '당권', '납부방법', '인출일', '약정금액',
    `지난 ${prior}개월 간 납부`, '마지막 납부', '구분', ...months.map(monthLabel), '연락함', '상태'];
  const rows = list.map((x) => [
    x.region, x.id, x.name, x.phone, x.rights ? 'Y' : x.rights === false ? 'N' : '',
    METHOD_LABEL[x.method] || x.method, x.draw ? `${x.draw}일` : '', x.pledge || '',
    `${x.priorPaid}회`, x.lastPaid ? monthLabel(x.lastPaid) : '', x.kind,
    ...months.map((mm) => (mm in x.paid ? '●' : '')),
    contacted.has(x.id) ? '연락함' : '', x.inList ? '' : '명단에 없음(탈당 등)',
  ]);
  return [head, ...rows];
}

// 당원현황 표: 2단 머리 + 지역 줄 + 총계 줄. 표 복사·엑셀·화면이 같이 쓴다.
// 칸: 지역 | 직전 대비 입당·탈당 | 당원수(당권자) | 9기 누계 입당·탈당·증감 | 올해 누계 입당·탈당·증감 | 비고
export function memberReportTable(rep) {
  const head1 = [
    { text: '지역위원회', rowspan: 2 },
    { text: '직전 대비', colspan: 2 },
    { text: '당원수\n(당권자)', rowspan: 2 },
    { text: '9기 누계', colspan: 3 },
    { text: '올해 누계', colspan: 3 },
    { text: '비고', rowspan: 2 },
  ];
  const head2 = ['입당', '탈당', '입당', '탈당', '증감', '입당', '탈당', '증감'];
  const cell = (n) => (n == null ? '-' : fmtNum(n));
  const per = (p) => (p ? [cell(p.in), cell(p.out), fmtSigned(p.delta)] : ['', '', '']);
  const line = (r) => [
    r.region, cell(r.in), cell(r.out),
    `${fmtNum(r.members)}(${r.rights == null ? '-' : fmtNum(r.rights)})`,
    ...per(r.term), ...per(r.year), r.note || '',
  ];
  const body = [...rep.rows.map(line), line({ ...rep.total, note: '' })];
  const notes = [];
  if (rep.prevDate) notes.push(`직전 대비: ${rep.prevDate} 기록과 비교`);
  if (rep.term.ok) notes.push(`9기 누계: ${rep.term.start} 시작(기준 기록 ${rep.term.baseDate})`);
  else notes.push(`9기 누계: 장부에 ${rep.term.start} 또는 그 전 기록이 없어 비워 둡니다. 설정 → [출발점 만들기]를 누르면 채워집니다.`);
  if (rep.year.ok) notes.push(`올해 누계: ${rep.year.start} 시작(기준 기록 ${rep.year.baseDate})`);
  else notes.push(`올해 누계: 장부에 ${rep.year.start} 또는 그 전 기록이 없어 비워 둡니다. 그 무렵 숫자를 장부에 넣거나, 설정에서 올해 시작일을 장부에 있는 날짜로 바꾸면 채워집니다.`);
  if (rep.estimated) notes.push('입당·탈당은 명단 비교 자료가 없어 승인일로 추정한 값입니다.');
  return { head1, head2, body, notes };
}

// 당비현황: 그달(처리월) 지역별 납부자·금액·특별당비와 전월 대비
// regions: 당원 명단에 있는 지역(낸 사람이 0명인 지역도 줄로 넣기 위함). 경남 목록을 고정으로 넣지 않는다(다른 시도 대비).
export function feeReport({ fee = {}, special = {}, month, exclude = [], regions: listed = [] }) {
  const prevMonth = monthAdd(month, -1);
  const statsOf = (m) => (fee[m] ? feeStats(fee[m].rows, special[m]?.rows || [], { exclude }) : null);
  const now = statsOf(month) || {};
  const prev = statsOf(prevMonth);
  const regions = regionSort([...listed, ...Object.keys(now), ...Object.keys(prev || {})]);
  const zero = { payers: 0, amount: 0, spCount: 0, spAmount: 0 };
  const line = (reg) => {
    const s = now[reg] || zero;
    const p = prev ? prev[reg] || zero : null;
    return { region: reg, ...s, dPayers: p ? s.payers - p.payers : null, dAmount: p ? s.amount - p.amount : null, dSp: p ? s.spAmount - p.spAmount : null };
  };
  return { month, prevMonth, hasPrev: Boolean(prev), hasSpecial: Boolean(special[month]), rows: regions.map(line), total: line(TOTAL) };
}

export function feeReportTable(rep) {
  const head = ['지역위원회', '납부자', '당비', '특별당비 건수', '특별당비', '전월 대비 납부자', '전월 대비 당비', '전월 대비 특별당비'];
  const line = (r) => [r.region, fmtNum(r.payers), fmtNum(r.amount), fmtNum(r.spCount), fmtNum(r.spAmount), fmtSigned(r.dPayers), fmtSigned(r.dAmount), fmtSigned(r.dSp)];
  const notes = [`${monthLabel(rep.month).replace('분', '')} 처리분 기준. 납부자는 사람 수(밀린 달을 함께 내도 1명).`];
  if (!rep.hasPrev) notes.push(`${monthLabel(rep.prevMonth).replace('분', '')} 자료가 없어 전월 대비는 비워 둡니다.`);
  if (!rep.hasSpecial) notes.push('이 달 특당비 내역은 받지 않았습니다. 특별당비는 당비 내역의 특별당비 칸만 셌습니다.');
  return { head, body: [...rep.rows.map(line), line(rep.total)], notes };
}

// ------------------------------------------------------------------ 장부 내보내기·가져오기

export const LEDGER_COLS = ['기준일', '지역', '당원수', '당권자수', '입당', '탈당', '비고'];

export function ledgerToAoa(ledger) {
  const rows = [...ledger].sort((a, b) =>
    a.date.localeCompare(b.date) ||
    (a.region === TOTAL) - (b.region === TOTAL) ||
    regionSort([a.region, b.region]).indexOf(a.region) - regionSort([a.region, b.region]).indexOf(b.region));
  return [LEDGER_COLS, ...rows.map((r) => [r.date, r.region, r.members, r.rights, r.in, r.out, r.note || ''])];
}

// 엑셀 시트(2차원 배열)를 장부로. 앱이 쓰던 당원현황_누계.xlsx의 '당원' 시트도 같은 칸이다.
// 돌려주는 값: { ledger, dates, skipped } — 필수 칸이 없으면 오류.
export function ledgerFromAoa(aoa) {
  const hi = aoa.findIndex((r) => r && r.map((c) => String(c ?? '').trim()).includes('기준일'));
  if (hi < 0) throw new Error("장부 파일에서 '기준일' 칸을 찾지 못했습니다. 이 프로그램이나 예전 앱에서 내보낸 장부인지 확인해 주세요.");
  const head = aoa[hi].map((c) => String(c ?? '').trim());
  for (const n of ['기준일', '지역', '당원수']) {
    if (!head.includes(n)) throw new Error(`장부 파일에 '${n}' 칸이 없습니다.`);
  }
  const at = (r, n) => (head.includes(n) ? r[head.indexOf(n)] : null);
  const opt = (v) => (v == null || String(v).trim() === '' ? null : toInt(v));
  const ledger = [];
  let skipped = 0;
  for (const r of aoa.slice(hi + 1)) {
    if (!r) continue;
    const rawDate = at(r, '기준일');
    const date = rawDate instanceof Date ? localDate(rawDate) : normDate(rawDate);
    const region = String(at(r, '지역') ?? '').trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !region) {
      if (String(rawDate ?? '').trim() || region) skipped += 1;
      continue;
    }
    const note = String(at(r, '비고') ?? '').trim();
    const mv = (word) => toInt((note.match(new RegExp(`${word}\\s*(\\d+)`)) || [])[1]);
    ledger.push({
      date, region, members: opt(at(r, '당원수')), rights: opt(at(r, '당권자수')),
      in: opt(at(r, '입당')), out: opt(at(r, '탈당')), moveIn: mv('전입'), moveOut: mv('전출'), note,
    });
  }
  if (!ledger.length) throw new Error('장부 파일에 읽을 줄이 없습니다.');
  return { ledger, dates: ledgerDates(ledger), skipped };
}

// ------------------------------------------------------------------ 올해 시작 숫자(이동내역 거꾸로 계산)
// 사이트의 승인·복당·탈당·지역변경 요청 목록(처리된 것 포함)을 읽어, 오늘 당원 수에서 거꾸로
// 과거 어느 날의 지역별 당원 수와 그 사이 입당·탈당·전입·전출을 계산한다. 한 번만 쓰는 기능.
// 이름은 지역 이동 중복을 걸러내는 데만 잠깐 쓰고 저장하지 않는다.

const H_QS = 'order_field=&order_updown=&key_branch=&key_type=&key_sex=&key_job=&key_confirm=&key=kor_name&keyword=';
export const HISTORY_SOURCES = [
  { key: 'join', label: '당원승인요청', path: 'confirmMgr/confirmAppList.php', qs: `${H_QS}&key_right=&key_mfee_seq=`, cols: { region: '지역', ok: '승인여부', date: '승인일', name: '이름(성별)' }, opt: ['name'] },
  { key: 'return', label: '당원복당요청', path: 'confirmMgr/confirmReturnList.php', qs: `${H_QS}&key_right=&key_mfee_seq=`, cols: { region: '지역', ok: '승인여부', date: '승인일', name: '이름(성별)' }, opt: ['name'] },
  { key: 'withdraw', label: '당원탈당요청', path: 'confirmMgr/withdrawAppList.php', qs: `${H_QS}&key_sub_branch=&key_withdraw_hp_yn=&key_35=`, cols: { region: '지역', ok: '탈당승인', date: '승인일', name: '이름(성별)' }, opt: ['name'] },
  { key: 'move', label: '지역위원회 변경요청', path: 'confirmMgr/branchAppList.php', qs: `${H_QS}&key_inout=`, cols: { kind: '구분', name: '이름(성별)', from: '기존지역위', to: '요청지역위', fromWide: '기존광역', toWide: '요청광역', ok: '승인', date: '승인일', req: '요청일' }, opt: ['kind', 'fromWide', 'toWide'] },
];

// 처리 상태: 분명히 끝난 값만 센다. 분명히 안 끝난 값은 뺀다. 그 밖의 값은 세지 않고 '모르는 값'으로 알린다.
const DONE = /^(승인|승인완료|완료|처리|처리완료|탈당|탈당완료|탈당승인|Y)$/;
const NOT_DONE = /반려|취소|거부|거절|대기|미승인|미처리|불가|보류|^N$|^미$/;
const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s);

// raw: { join: {rows:[{지역,승인여부,승인일}...]}, ... } (사이트 화면에서 필요한 칸만 뽑은 것)
export function historyEvents(raw, regions = REGION_ORDER) {
  const known = new Set(regions);
  const events = [];
  const diag = {};
  for (const src of HISTORY_SOURCES) {
    const got = raw[src.key];
    const d = { label: src.label, rows: 0, counted: 0, notDone: 0, unknownOk: {}, noDate: 0, dup: 0, okValues: {}, kinds: {}, otherRegions: {}, first: null, last: null, missing: got?.missing || [], truncated: Boolean(got?.truncated) };
    diag[src.key] = d;
    if (!got || !got.rows) continue;
    const seen = new Set();
    for (const r of got.rows) {
      d.rows += 1;
      const c = src.cols;
      const ok = String(r[c.ok] ?? '').trim();
      d.okValues[ok || '(빈칸)'] = (d.okValues[ok || '(빈칸)'] || 0) + 1;
      if (c.kind) d.kinds[r[c.kind] || '(빈칸)'] = (d.kinds[r[c.kind] || '(빈칸)'] || 0) + 1;
      const date = normDate(r[c.date]).slice(0, 10);
      if (NOT_DONE.test(ok)) { d.notDone += 1; continue; }
      // 처리 상태도 처리일도 비어 있으면 아직 처리 안 된 요청
      if (!ok && !isDate(date)) { d.notDone += 1; continue; }
      if (!DONE.test(ok)) { d.unknownOk[ok || '(빈칸)'] = (d.unknownOk[ok || '(빈칸)'] || 0) + 1; continue; }
      if (!isDate(date)) { d.noDate += 1; continue; }
      if (src.key === 'move') {
        const from = String(r[c.from] ?? '').trim();
        const to = String(r[c.to] ?? '').trim();
        // 같은 이동이 전출·전입으로 두 번 나올 수 있어 한 번만 센다
        const sig = [r[c.name], from, to, date, normDate(r[c.req]).slice(0, 10)].join('|');
        if (seen.has(sig)) { d.dup += 1; continue; }
        seen.add(sig);
        for (const reg of [from, to]) if (reg && !known.has(reg)) d.otherRegions[reg] = (d.otherRegions[reg] || 0) + 1;
        events.push({ type: 'move', date, from: known.has(from) ? from : null, to: known.has(to) ? to : null, fromName: from, toName: to, name: String(r[c.name] ?? '') });
      } else {
        const region = String(r[c.region] ?? '').trim();
        if (!known.has(region)) d.otherRegions[region || '(빈칸)'] = (d.otherRegions[region || '(빈칸)'] || 0) + 1;
        events.push({ type: src.key === 'withdraw' ? 'out' : 'in', src: src.key, date, region: known.has(region) ? region : null, name: c.name ? String(r[c.name] ?? '') : '' });
      }
      d.counted += 1;
      if (!d.first || date < d.first) d.first = date;
      if (!d.last || date > d.last) d.last = date;
    }
  }
  return { events, diag };
}

// 오늘(nowDate) 지역별 당원 수에서 거꾸로: target 날 끝의 지역별 당원 수
export function countsAt({ nowCounts, nowDate, events, target }) {
  const c = { ...nowCounts };
  const add = (reg, k) => { if (reg) c[reg] = (c[reg] || 0) + k; };
  for (const e of events) {
    if (!(e.date > target && e.date <= nowDate)) continue;
    if (e.type === 'in') add(e.region, -1);
    else if (e.type === 'out') add(e.region, +1);
    else { add(e.to, -1); add(e.from, +1); }
  }
  return c;
}

// (from, to] 사이 지역별 입당·탈당·전입·전출
export function flowsBetween(events, from, to) {
  const f = {};
  const at = (reg) => (f[reg] ||= { in: 0, out: 0, moveIn: 0, moveOut: 0 });
  for (const e of events) {
    if (!(e.date > from && e.date <= to)) continue;
    if (e.type === 'in' && e.region) at(e.region).in += 1;
    else if (e.type === 'out' && e.region) at(e.region).out += 1;
    else if (e.type === 'move') {
      if (e.to) at(e.to).moveIn += 1;
      if (e.from) at(e.from).moveOut += 1;
    }
  }
  return f;
}

export function regionCounts(members) {
  const c = {};
  for (const m of members) c[m.region] = (c[m.region] || 0) + 1;
  return c;
}

// 장부의 date 줄과 계산값을 지역별로 나란히(검증용)
export function compareCounts(ledger, date, calc) {
  const rows = ledger.filter((r) => r.date === date && r.region !== TOTAL);
  if (!rows.length) return null;
  const lines = regionSort(rows.map((r) => r.region)).map((reg) => {
    const l = rows.find((r) => r.region === reg).members;
    const v = calc[reg] ?? 0;
    return { region: reg, ledger: l, calc: v, diff: l == null ? null : v - l };
  });
  const sum = (k) => lines.reduce((s, x) => s + (x[k] ?? 0), 0);
  return { date, lines, total: { region: TOTAL, ledger: sum('ledger'), calc: sum('calc'), diff: sum('calc') - sum('ledger') } };
}

// 장부에 올해 시작 줄을 넣고, 다음 기록일 줄의 빈 입당·탈당·전입·전출 칸을 채운다.
// 이미 숫자가 있는 칸은 건드리지 않는다.
export function addYearStart({ ledger, counts, startDate, events, note = '이동내역으로 거꾸로 계산' }) {
  const regions = regionSort(Object.keys(counts).filter((r) => r !== TOTAL));
  const startRows = regions.map((reg) => ({ date: startDate, region: reg, members: counts[reg], rights: null, in: null, out: null, moveIn: 0, moveOut: 0, note }));
  startRows.push({ date: startDate, region: TOTAL, members: regions.reduce((s, r) => s + counts[r], 0), rights: null, in: null, out: null, moveIn: 0, moveOut: 0, note });
  const rest = ledger.filter((r) => r.date !== startDate);
  const next = ledgerDates(rest.filter((r) => r.date > startDate))[0] || null;
  let filled = 0;
  let out = rest;
  if (next) {
    const f = flowsBetween(events, startDate, next);
    const tot = { in: 0, out: 0, moveIn: 0, moveOut: 0 };
    for (const v of Object.values(f)) for (const k in tot) tot[k] += v[k];
    out = rest.map((r) => {
      if (r.date !== next) return r;
      const v = r.region === TOTAL ? tot : f[r.region] || { in: 0, out: 0, moveIn: 0, moveOut: 0 };
      const nr = { ...r };
      // 입당·탈당이 비어 있던 줄(그 구간을 몰랐던 줄)만 채운다. 전입·전출도 그때만 넣고 비고에 적는다.
      if (nr.in == null && nr.out == null) {
        nr.in = v.in;
        nr.out = v.out;
        nr.moveIn = v.moveIn;
        nr.moveOut = v.moveOut;
        filled += 2;
        if (nr.note === '비교 기준 없음') nr.note = '출발점과 비교(이동내역)';
        const mv = [v.moveIn ? `전입 ${v.moveIn}` : '', v.moveOut ? `전출 ${v.moveOut}` : ''].filter(Boolean).join(', ');
        if (r.region !== TOTAL && mv) nr.note = [nr.note, mv].filter(Boolean).join(', ');
      } else {
        for (const k of ['in', 'out']) if (nr[k] == null) { nr[k] = v[k]; filled += 1; }
      }
      return nr;
    });
  }
  return { ledger: [...startRows, ...out], next, filled };
}

// 출발점 여러 개(예: 9기 시작 전날, 올해 시작 전날)를 장부에 넣는다.
// 늦은 날부터 넣어야 각 출발점 다음 줄의 빈 입당·탈당을 그 구간으로 채울 수 있다.
// 장부에 같은 날 기록이 이미 있으면(직접 넣은 숫자) 그 날은 건드리지 않는다.
export function addStartPoints({ ledger, points, events, note = '이동내역으로 거꾸로 계산' }) {
  let out = ledger;
  const done = [];
  const kept = [];
  const dates = [...new Set(points.map((p) => p.date))].sort().reverse();
  for (const date of dates) {
    const p = points.find((x) => x.date === date);
    if (out.some((r) => r.date === date && r.note !== note)) {
      kept.push(date);
      continue;
    }
    const r = addYearStart({ ledger: out, counts: p.counts, startDate: date, events, note });
    out = r.ledger;
    done.push({ date, next: r.next });
  }
  return { ledger: out, done, kept };
}

// ------------------------------------------------------------------ 당원현황 더 보기(흐름·명단·당권자 비율·기간 누계)
// 이동내역(events)은 화면에서만 잠시 쓰고 저장하지 않는다. 저장하는 것은 지역별 인원 숫자뿐.

function monthEnd(month) {
  const [y, m] = month.split('-').map(Number);
  const d = new Date(Date.UTC(y, m, 0));
  return d.toISOString().slice(0, 10);
}

// 지난 n개월 각 달 말일 끝의 지역별 당원 수(이번 달은 오늘 숫자)
export function monthEnds({ nowCounts, nowDate, events, months = 12 }) {
  const cur = monthOf(nowDate);
  const out = [];
  for (let k = months - 1; k >= 1; k--) {
    const date = monthEnd(monthAdd(cur, -k));
    out.push({ month: monthAdd(cur, -k), date, counts: countsAt({ nowCounts, nowDate, events, target: date }) });
  }
  out.push({ month: cur, date: nowDate, counts: { ...nowCounts } });
  return out;
}

const sumCounts = (c) => Object.entries(c).filter(([r]) => r !== NO_REGION).reduce((s, [, v]) => s + v, 0);
export const totalOf = sumCounts;

// 기간 누계: from 날 시작 ~ to 날 끝. 지역별 시작·입당·탈당·전입·전출·끝·증감
export function periodSummary({ nowCounts, nowDate, events, from, to }) {
  const before = (d) => { const x = new Date(`${d}T00:00:00Z`); x.setUTCDate(x.getUTCDate() - 1); return x.toISOString().slice(0, 10); };
  const s0 = before(from);
  const startC = countsAt({ nowCounts, nowDate, events, target: s0 });
  const endC = countsAt({ nowCounts, nowDate, events, target: to });
  const f = flowsBetween(events, s0, to);
  const regions = regionSort([...new Set([...Object.keys(startC), ...Object.keys(endC), ...Object.keys(f)])].filter((r) => r !== NO_REGION));
  const zero = { in: 0, out: 0, moveIn: 0, moveOut: 0 };
  const rows = regions.map((r) => {
    const v = f[r] || zero;
    const a = startC[r] ?? 0;
    const b = endC[r] ?? 0;
    return { region: r, start: a, in: v.in, out: v.out, moveIn: v.moveIn, moveOut: v.moveOut, end: b, delta: b - a };
  });
  const t = { region: TOTAL };
  for (const k of ['start', 'in', 'out', 'moveIn', 'moveOut', 'end', 'delta']) t[k] = rows.reduce((s, x) => s + x[k], 0);
  return { from, to, rows, total: t };
}

export function periodSummaryTable(sum) {
  const head = ['지역위원회', `시작(${sum.from})`, '입당', '탈당', '전입', '전출', `끝(${sum.to})`, '증감'];
  const line = (x) => [x.region, fmtNum(x.start), fmtNum(x.in), fmtNum(x.out), fmtNum(x.moveIn), fmtNum(x.moveOut), fmtNum(x.end), fmtSigned(x.delta)];
  return { head, body: [...sum.rows.map(line), line(sum.total)] };
}

// 입당·탈당·이동 명단(from 날 시작 ~ to 날 끝). 화면 표시용.
export function movementList(events, from, to) {
  const inRange = (e) => e.date >= from && e.date <= to;
  const ord = (r) => { const i = REGION_ORDER.indexOf(r); return i < 0 ? 999 : i; };
  const byDate = (a, b) => ord(a.region ?? a.to) - ord(b.region ?? b.to) || a.date.localeCompare(b.date);
  const ins = events.filter((e) => e.type === 'in' && inRange(e)).map((e) => ({ date: e.date, region: e.region || '(다른 지역)', name: e.name, kind: e.src === 'return' ? '복당' : '입당' })).sort(byDate);
  const outs = events.filter((e) => e.type === 'out' && inRange(e)).map((e) => ({ date: e.date, region: e.region || '(다른 지역)', name: e.name, kind: '탈당' })).sort(byDate);
  const moves = events.filter((e) => e.type === 'move' && inRange(e) && (e.from || e.to)).map((e) => ({ date: e.date, name: e.name, from: e.fromName, to: e.toName, kind: e.from && e.to ? '지역 이동' : e.to ? '다른 시도에서 전입' : '다른 시도로 전출' })).sort(byDate);
  return { ins, outs, moves };
}

// 당권자 비율: date 기록과 compareDate 기록의 지역별 당권자/당원
export function rightsRatio(ledger, date, compareDate = null) {
  const at = (d) => Object.fromEntries(ledger.filter((r) => r.date === d).map((r) => [r.region, r]));
  const now = at(date);
  const prev = compareDate ? at(compareDate) : {};
  const pct = (r) => (r && r.rights != null && r.members ? (r.rights / r.members) * 100 : null);
  const regions = regionSort(Object.keys(now).filter((r) => r !== TOTAL));
  const line = (reg) => {
    const a = pct(prev[reg]);
    const b = pct(now[reg]);
    return { region: reg, members: now[reg]?.members ?? null, rights: now[reg]?.rights ?? null, pct: b, prevPct: a, change: a == null || b == null ? null : b - a };
  };
  return { date, compareDate, rows: regions.map(line), total: line(TOTAL) };
}

export function rightsRatioTable(rr) {
  const p = (v) => (v == null ? '-' : `${v.toFixed(1)}%`);
  const ch = (v) => (v == null ? '-' : `${v > 0 ? '+' : v < 0 ? '−' : ''}${Math.abs(v).toFixed(1)}%p`);
  const head = ['지역위원회', '당원수', '당권자', '당권자 비율', `비교(${rr.compareDate || '-'})`, '변화'];
  const line = (x) => [x.region, fmtNum(x.members), fmtNum(x.rights), p(x.pct), p(x.prevPct), ch(x.change)];
  return { head, body: [...rr.rows.map(line), line(rr.total)] };
}

// 기간 누계 월별: from~to를 달마다 나눠(처음·마지막 달은 기간 안쪽만) 한 지역(또는 전체)의 흐름
export function periodMonthly({ nowCounts, nowDate, events, from, to, region = '' }) {
  const pick = (c) => (region ? c[region] ?? 0 : sumCounts(c));
  const pickF = (f, k) => (region ? f[region]?.[k] ?? 0 : Object.entries(f).filter(([r]) => r !== NO_REGION).reduce((s, [, v]) => s + v[k], 0));
  const before = (d) => { const x = new Date(`${d}T00:00:00Z`); x.setUTCDate(x.getUTCDate() - 1); return x.toISOString().slice(0, 10); };
  const rows = [];
  for (let m = monthOf(from); m <= monthOf(to); m = monthAdd(m, 1)) {
    const a = from > `${m}-01` ? from : `${m}-01`;
    const b = to < monthEnd(m) ? to : monthEnd(m);
    const f = flowsBetween(events, before(a), b);
    const start = pick(countsAt({ nowCounts, nowDate, events, target: before(a) }));
    const end = pick(countsAt({ nowCounts, nowDate, events, target: b }));
    rows.push({ month: m, from: a, to: b, start, in: pickF(f, 'in'), out: pickF(f, 'out'), moveIn: pickF(f, 'moveIn'), moveOut: pickF(f, 'moveOut'), end, delta: end - start });
  }
  const t = { month: '합계', start: rows[0]?.start ?? 0, end: rows.at(-1)?.end ?? 0 };
  for (const k of ['in', 'out', 'moveIn', 'moveOut']) t[k] = rows.reduce((s, x) => s + x[k], 0);
  t.delta = t.end - t.start;
  return { from, to, region, rows, total: t };
}

export function periodMonthlyTable(pm) {
  const head = ['달', '시작', '입당', '탈당', '전입', '전출', '끝', '증감'];
  const label = (x) => (x.month === '합계' ? '합계' : `${x.month}${x.from.slice(8) !== '01' || x.to !== monthEnd(x.month) ? ` (${Number(x.from.slice(8))}~${Number(x.to.slice(8))}일)` : ''}`);
  const line = (x) => [label(x), fmtNum(x.start), fmtNum(x.in), fmtNum(x.out), fmtNum(x.moveIn), fmtNum(x.moveOut), fmtNum(x.end), fmtSigned(x.delta)];
  return { head, body: [...pm.rows.map(line), line(pm.total)] };
}

// 기간 누계 지역×월: 줄=지역, 칸=달. metric: end(말일 당원수)|in|out|moveIn|moveOut|delta
export const MATRIX_METRICS = { end: '말일 당원수', in: '입당', out: '탈당', moveIn: '전입', moveOut: '전출', delta: '증감' };
export function periodMatrix({ nowCounts, nowDate, events, from, to, metric = 'end' }) {
  const regions = regionSort(Object.keys(nowCounts).filter((r) => r !== NO_REGION));
  const per = (region) => periodMonthly({ nowCounts, nowDate, events, from, to, region });
  const all = per('');
  const months = all.rows.map((r) => r.month);
  // 말일 당원수는 맨 앞에 시작 인원을, 나머지는 맨 뒤에 합계를 둔다
  const lineOf = (pm) => ({ cells: pm.rows.map((r) => r[metric]), total: metric === 'end' ? pm.total.start : pm.total[metric], start: pm.total.start, end: pm.total.end });
  const rows = regions.map((region) => ({ region, ...lineOf(per(region)) }));
  return { from, to, metric, months, rows, total: { region: TOTAL, ...lineOf(all) } };
}

export function periodMatrixTable(mx) {
  const months = mx.months.map((m) => `${Number(m.slice(5))}월`);
  const f = mx.metric === 'delta' ? fmtSigned : fmtNum;
  const isEnd = mx.metric === 'end';
  if (isEnd) {
    // 말일 당원수: 맨 오른쪽 '증감 누계'(마지막 달 − 시작), 맨 아래 '증감 누계'(달마다 총계 − 시작 총계)
    const head = ['지역위원회', `시작(${mx.from})`, ...months, '증감 누계'];
    const line = (x) => [x.region, f(x.total), ...x.cells.map(f), fmtSigned((x.cells.at(-1) ?? x.total) - x.total)];
    const t = mx.total;
    const cum = ['증감 누계', '-', ...t.cells.map((v) => fmtSigned(v - t.total)), fmtSigned((t.cells.at(-1) ?? t.total) - t.total)];
    return { head, body: [...mx.rows.map(line), line(t), cum] };
  }
  if (mx.metric === 'delta') {
    // 증감: 시작 인원과 끝 인원을 따로 적는다(시작 + 합계 = 끝)
    const head = ['지역위원회', `시작(${mx.from})`, ...months, '합계', `끝(${mx.to})`];
    const line = (x) => [x.region, fmtNum(x.start), ...x.cells.map(f), f(x.total), fmtNum(x.end)];
    return { head, body: [...mx.rows.map(line), line(mx.total)] };
  }
  const head = ['지역위원회', ...months, '합계'];
  const line = (x) => [x.region, ...x.cells.map(f), f(x.total)];
  return { head, body: [...mx.rows.map(line), line(mx.total)] };
}

// ------------------------------------------------------------------ 당비현황 더 보기(월별 추이·납부율·올해 누계·특별당비 상세)

const statsAt = (fee, special, m, exclude = []) => (fee[m] ? feeStats(fee[m].rows, special[m]?.rows || [], { exclude }) : null);

// 월별 추이: 가진 달 중 최근 n개월. region 비우면 전체
export function feeTrend({ fee = {}, special = {}, region = '', months = 12, cur, exclude = [] }) {
  const last = cur || Object.keys(fee).sort().at(-1);
  if (!last) return { rows: [], region };
  const rows = [];
  for (let k = months - 1; k >= 0; k--) {
    const m = monthAdd(last, -k);
    const st = statsAt(fee, special, m, exclude);
    if (!st) { rows.push({ month: m, missing: true }); continue; }
    const s = st[region || TOTAL] || { payers: 0, amount: 0, spCount: 0, spAmount: 0 };
    rows.push({ month: m, ...s, hasSpecial: Boolean(special[m]) });
  }
  return { rows, region };
}

export function feeTrendTable(tr) {
  const head = ['달(처리분)', '납부자', '당비', '특별당비 건수', '특별당비', '전월 대비 납부자', '전월 대비 당비'];
  let prev = null;
  const body = tr.rows.map((r) => {
    if (r.missing) { prev = null; return [r.month, '자료 없음', '', '', '', '', '']; }
    const line = [r.hasSpecial ? r.month : `${r.month} (특당비 내역 없음)`, fmtNum(r.payers), fmtNum(r.amount), fmtNum(r.spCount), fmtNum(r.spAmount),
      prev ? fmtSigned(r.payers - prev.payers) : '-', prev ? fmtSigned(r.amount - prev.amount) : '-'];
    prev = r;
    return line;
  });
  return { head, body };
}

// 지역별 납부율: 그달 처리분 납부자 ÷ 당원수, ÷ 당권자. 당원수·당권자는 그달 말일에 가장 가까운(앞선) 장부 기록.
export function payRate({ fee = {}, special = {}, month, ledger = [] }) {
  const st = statsAt(fee, special, month);
  if (!st) return null;
  // 지역별 당권자 수가 있는 기록만(9/12 운영위처럼 총계만 있는 날은 뺀다)
  const withRights = ledgerDates(ledger.filter((r) => r.region !== TOTAL && r.rights != null));
  const end = monthEnd(month);
  const base = withRights.filter((d) => d <= end).at(-1) || withRights.find((d) => d > end) || null;
  const at = Object.fromEntries(ledger.filter((r) => r.date === base).map((r) => [r.region, r]));
  // 지역 없는 납부자도 줄로 보여 줘야 총계와 맞는다(보고표와 같게)
  const regions = regionSort([...new Set([...Object.keys(st), ...Object.keys(at)])].filter((r) => r !== TOTAL));
  const pct = (a, b) => (b ? (a / b) * 100 : null);
  const line = (reg) => {
    const p = st[reg]?.payers ?? 0;
    const m = at[reg]?.members ?? null;
    const k = at[reg]?.rights ?? null;
    return { region: reg, payers: p, members: m, rights: k, rateMembers: m == null ? null : pct(p, m), rateRights: k == null ? null : pct(p, k) };
  };
  return { month, base, rows: regions.map(line), total: line(TOTAL) };
}

export function payRateTable(pr) {
  const p = (v) => (v == null ? '-' : `${v.toFixed(1)}%`);
  const head = ['지역위원회', '납부자', '당원수', '당권자', '납부율(당원 대비)', '납부율(당권자 대비)'];
  const line = (x) => [x.region, fmtNum(x.payers), fmtNum(x.members), fmtNum(x.rights), p(x.rateMembers), p(x.rateRights)];
  return { head, body: [...pr.rows.map(line), line(pr.total)] };
}

// 올해 누계: year년 1월 ~ upto달 처리분. 당비·특별당비 합계, 연인원(달마다 납부자 합), 낸 사람(중복 없이)
export function feeYear({ fee = {}, special = {}, year, upto, exclude = [] }) {
  const months = [];
  for (let m = `${year}-01`; m <= upto; m = monthAdd(m, 1)) months.push(m);
  const have = months.filter((m) => fee[m]);
  const missing = months.filter((m) => !fee[m]);
  const agg = {};
  const at = (reg) => (agg[reg] ||= { amount: 0, spCount: 0, spAmount: 0, payerMonths: 0, ids: new Set() });
  for (const m of have) {
    const st = feeStats(fee[m].rows, special[m]?.rows || [], { exclude });
    for (const [reg, s] of Object.entries(st)) {
      if (reg === TOTAL) continue;
      const a = at(reg);
      a.amount += s.amount;
      a.spCount += s.spCount;
      a.spAmount += s.spAmount;
      a.payerMonths += s.payers;
    }
    for (const r of fee[m].rows) if (r.amt > 0) { at(r.region).ids.add(r.id); at(TOTAL).ids.add(r.id); }
  }
  const regions = regionSort(Object.keys(agg).filter((r) => r !== TOTAL));
  const line = (reg) => ({ region: reg, amount: agg[reg]?.amount ?? 0, spCount: agg[reg]?.spCount ?? 0, spAmount: agg[reg]?.spAmount ?? 0, payerMonths: agg[reg]?.payerMonths ?? 0, payers: agg[reg]?.ids.size ?? 0 });
  const rows = regions.map(line);
  const total = { region: TOTAL, payers: agg[TOTAL]?.ids.size ?? 0 };
  for (const k of ['amount', 'spCount', 'spAmount', 'payerMonths']) total[k] = rows.reduce((s, x) => s + x[k], 0);
  return { year, upto, have, missing, rows, total };
}

export function feeYearTable(fy) {
  const head = ['지역위원회', '낸 사람(중복 없이)', '연인원', '당비 합계', '특별당비 건수', '특별당비 합계', '합계'];
  const line = (x) => [x.region, fmtNum(x.payers), fmtNum(x.payerMonths), fmtNum(x.amount), fmtNum(x.spCount), fmtNum(x.spAmount), fmtNum(x.amount + x.spAmount)];
  return { head, body: [...fy.rows.map(line), line(fy.total)] };
}

// 화면에 보이는 특별당비 종류 이름(사이트 칸 이름 '지역당특별당비'는 읽을 때 그대로 쓰고, 보일 때만 '지역위'로)
export const spLabel = (c) => c.replace('특별당비', '').replace('지역당', '지역위');

// 특별당비 상세: 그달 지역별 × 종류별 건수·금액(당비 파일의 특별당비 칸 + 특당비 파일)
export function spDetail({ fee = {}, special = {}, month, exclude = [] }) {
  if (!fee[month]) return null;
  const rows = [...fee[month].rows, ...(special[month]?.rows || [])];
  const old = rows.some((r) => r.sp > 0 && !r.spBy);
  const agg = {};
  const cnt = {}; // 합계 건수: 한 줄(한 번 낸 것)을 1건으로(보고표와 같은 기준)
  const at = (reg) => (agg[reg] ||= Object.fromEntries(SPECIAL_COLS.map((c) => [c, { n: 0, amt: 0 }])));
  for (const r of rows) {
    if (!(spOf(r, exclude) > 0)) continue;
    cnt[r.region] = (cnt[r.region] || 0) + 1;
    at(r.region);
    for (const [c, v] of Object.entries(r.spBy || {})) {
      if (v > 0 && !exclude.includes(c)) {
        at(r.region)[c].n += 1;
        at(r.region)[c].amt += v;
      }
    }
  }
  const regions = regionSort(Object.keys(agg));
  const total = Object.fromEntries(SPECIAL_COLS.map((c) => [c, { n: regions.reduce((s, r) => s + agg[r][c].n, 0), amt: regions.reduce((s, r) => s + agg[r][c].amt, 0) }]));
  const used = SPECIAL_COLS.filter((c) => total[c].n > 0);
  const amtOf = (reg) => rows.filter((r) => r.region === reg && spOf(r, exclude) > 0).reduce((s, r) => s + spOf(r, exclude), 0);
  return {
    month, old, used,
    rows: regions.map((r) => ({ region: r, by: agg[r], count: cnt[r] || 0, amount: amtOf(r) })),
    total: { region: TOTAL, by: total, count: Object.values(cnt).reduce((s, v) => s + v, 0), amount: rows.filter((r) => spOf(r, exclude) > 0).reduce((s, r) => s + spOf(r, exclude), 0) },
    hasSpecialFile: Boolean(special[month]),
    // 어느 파일에서 왔는지(두 파일에 같은 납부가 겹치는지 확인용)
    fromFee: fee[month].rows.filter((r) => r.sp > 0).reduce((a, r) => ({ n: a.n + 1, amt: a.amt + r.sp }), { n: 0, amt: 0 }),
    fromSpecial: (special[month]?.rows || []).filter((r) => r.sp > 0).reduce((a, r) => ({ n: a.n + 1, amt: a.amt + r.sp }), { n: 0, amt: 0 }),
    // 같은 사람이 두 파일에 같은 금액으로 있는 경우(겹쳐 셌을 가능성)
    overlap: (() => {
      const key = (r) => `${r.id}|${r.sp}`;
      const inFee = new Set(fee[month].rows.filter((r) => r.sp > 0).map(key));
      return (special[month]?.rows || []).filter((r) => r.sp > 0 && inFee.has(key(r))).length;
    })(),
  };
}

export function spDetailTable(sd) {
  const cols = sd.used.length ? sd.used : SPECIAL_COLS.slice(0, 1);
  const head = ['지역위원회', ...cols.flatMap((c) => [`${spLabel(c)} 건수`, `${spLabel(c)} 금액`]), '합계 건수', '합계 금액'];
  const line = (x) => [x.region, ...cols.flatMap((c) => [fmtNum(x.by[c].n), fmtNum(x.by[c].amt)]), fmtNum(x.count), fmtNum(x.amount)];
  return { head, body: [...sd.rows.map(line), line(sd.total)] };
}
