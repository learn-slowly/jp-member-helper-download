// 화면: 당비 미납자 / 당원현황 / 당비현황 / 설정. 계산은 전부 core.js.
// 사이트에서 온 글자(이름 등)는 textContent로만 넣는다(HTML로 해석하지 않음).
import * as core from './core.js';

const $ = (id) => document.getElementById(id);
const XLSX = globalThis.XLSX;

// 작은 DOM 도구: h('span', { class: 'x' }, '글자', 자식…)
function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'checked') el.checked = Boolean(v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) el.append(k instanceof Node ? k : String(k));
  return el;
}

function toast(text) {
  const t = $('toast');
  t.textContent = text;
  t.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (t.hidden = true), 3500);
}

const today = () => core.localDate(new Date());

let store = {};
async function reload() {
  store = await chrome.storage.local.get(null);
}
const settings = () => ({ ...core.DEFAULT_SETTINGS, ...(store.settings || {}) });

// ------------------------------------------------------------------ 머리(상태 줄·지금 확인)

function renderTop() {
  const st = store.status;
  const last = store.meta?.lastSync && !st?.busy
    ? ` · 마지막 확인 ${new Date(store.meta.lastSync).toLocaleString('ko-KR', { month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`
    : '';
  $('status').textContent = (st?.text || '아직 확인한 적이 없습니다.') + last;
  $('check').disabled = Boolean(st?.busy);
}

$('check').addEventListener('click', async () => {
  $('check').disabled = true;
  $('status').textContent = '자료를 받는 중입니다… (1~2분)';
  const res = await chrome.runtime.sendMessage({ type: 'check' });
  if (res && !res.ok) toast(res.text);
});

// ------------------------------------------------------------------ 탭

const TABS = ['lapsed', 'members', 'fee', 'settings'];
function showTab(name) {
  for (const t of TABS) {
    $(t).hidden = t !== name;
    $(`tab-${t}`).setAttribute('aria-selected', String(t === name));
  }
  try {
    localStorage.setItem('tab', name);
  } catch {
    /* 저장 못 해도 괜찮음 */
  }
}
for (const t of TABS) $(`tab-${t}`).addEventListener('click', () => showTab(t));

// ------------------------------------------------------------------ 당비 미납자

let lapsedRes = null;

function contactedSet(cur) {
  const s = new Set();
  for (const k of Object.keys(store.contacted || {})) if (k.startsWith(`${cur}:`)) s.add(k.slice(cur.length + 1));
  return s;
}

function filters() {
  return {
    region: $('f-region').value,
    kind: $('f-kind').value,
    hideContacted: $('f-hide').checked,
    priorAll: $('f-prior').checked,
    q: $('f-q').value,
  };
}

let kindDefaulted = false; // 구분 기본값을 한 번만 넣기 위함

function fillSelect(sel, values, labelOf = (v) => v) {
  const keep = sel.value;
  sel.replaceChildren(sel.options[0] || h('option', { value: '' }, '전체'));
  for (const v of values) sel.append(h('option', { value: v }, labelOf(v)));
  if ([...sel.options].some((o) => o.value === keep)) sel.value = keep;
}

function renderLapsed() {
  if (!store.members || !store.fee) {
    $('lapsed-empty').textContent = '아직 자료가 없습니다. 당원관리 시스템(cs.justice21.org)에 로그인한 뒤 위의 [지금 확인]을 눌러 주세요.';
    $('lapsed-empty').hidden = false;
    $('lapsed-body').hidden = true;
    return;
  }
  $('lapsed-empty').hidden = true;
  $('lapsed-body').hidden = false;
  const s = settings();
  lapsedRes = core.findLapsed({ feeByMonth: store.fee, members: store.members.rows, today: today(), prior: s.prior });
  const { cur, last, counts: c } = lapsedRes;
  const contacted = contactedSet(cur);
  const left = lapsedRes.list.filter((x) => x.counted && !contacted.has(x.id)).length;

  $('big').textContent = `미납 ${c.total}명` + (c.total ? ` · 아직 연락 안 함 ${left}명` : '');
  const parts = [
    `${core.KIND.BOTH} ${c[core.KIND.BOTH]}명`,
    `${core.KIND.LAST} ${c[core.KIND.LAST]}명`,
    `${core.KIND.CUR} ${c[core.KIND.CUR]}명`,
  ];
  if (c.waiting) parts.push(`인출 대기 ${c.waiting}명(아직 미납으로 세지 않음)`);
  if (c.gone) parts.push(`명단에 없음 ${c.gone}명`);
  $('kinds').textContent = parts.join(' · ');
  $('f-prior').parentElement.lastChild.textContent = ` 앞선 ${s.prior}개월 다 낸 사람만`;

  fillSelect($('f-region'), core.regionSort(new Set(lapsedRes.list.map((x) => x.region))));
  fillSelect($('f-kind'), [core.KIND.BOTH, core.KIND.LAST, core.KIND.CUR, core.KIND.WAIT]);
  // 화면을 열 때 처음에는 '지난달만 미납'만 보여 준다(다 보려면 구분에서 '전체')
  if (!kindDefaulted) {
    $('f-kind').value = core.KIND.LAST;
    kindDefaulted = true;
  }

  const shown = core.filterLapsed(lapsedRes.list, filters(), contacted);
  $('shown').textContent = shown.length === lapsedRes.list.length ? '' : `조건에 맞는 사람 ${shown.length}명`;

  const months = core.monthsNeeded(cur, s.prior);
  const fresh = new Set(store.meta?.lastNew || []);
  const list = $('lapsed-list');
  const openState = Object.fromEntries([...list.querySelectorAll('details')].map((d) => [d.dataset.key, d.open]));
  list.replaceChildren();

  if (!lapsedRes.list.length) {
    list.append(h('div', { class: 'empty' }, '지금은 당비 미납자가 없습니다.'));
    return;
  }
  if (!shown.length) {
    list.append(h('div', { class: 'empty' }, '조건에 맞는 사람이 없습니다. 위의 필터를 바꿔 보세요.'));
    return;
  }

  const groups = new Map();
  for (const x of shown) {
    const key = x.inList ? x.region : '__gone';
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(x);
  }
  // 미납자가 있는 지역을 먼저, 인출 대기만 있는 지역은 뒤로, 명단에 없음은 맨 뒤
  const rank = ([key, people]) => (key === '__gone' ? 2 : people.some((x) => x.counted) ? 0 : 1);
  const ordered = [...groups].sort((a, b) => rank(a) - rank(b)); // 같은 순위 안에서는 지역 순서 유지
  for (const [key, people] of ordered) {
    const gone = key === '__gone';
    const counted = people.filter((x) => x.counted).length;
    const label = gone ? '명단에 없음(탈당 등) — 숫자·알림에서 뺌' : key;
    const d = h('details', { class: `group${gone ? ' gone' : ''}`, 'data-key': key },
      h('summary', {}, label, h('span', { class: 'count' }, gone ? `${people.length}명` : `미납 ${counted}명${people.length > counted ? ` · 대기 ${people.length - counted}명` : ''}`)));
    // 인출 대기만 있는 묶음과 명단에 없음 묶음은 접어 둔다
    d.open = openState[key] ?? (!gone && counted > 0);
    for (const x of people) d.append(personRow(x, { cur, last, prior: s.prior, months, contacted, fresh }));
    list.append(d);
  }
}

function personRow(x, { cur, last, prior, months, contacted, fresh }) {
  const done = contacted.has(x.id);
  const cells = months.map((m) => {
    const label = `${Number(m.slice(5))}월`;
    if (m in x.paid) return h('span', { class: 'paid', title: `${core.monthLabel(m)} 냄` }, `✓ ${label}`);
    if (m === cur && x.kind !== core.KIND.BOTH && x.kind !== core.KIND.CUR && x.draw) {
      return h('span', { class: 'wait', title: '아직 인출 전' }, `${label} 대기`);
    }
    if (m === last || (m === cur && x.missCur)) return h('span', { class: 'miss', title: `${core.monthLabel(m)} 안 냄` }, label);
    return h('span', { title: `${core.monthLabel(m)} 안 냄` }, label);
  });
  const box = h('input', {
    type: 'checkbox',
    checked: done,
    onchange: (e) => setContacted(cur, x.id, e.target.checked),
  });
  const tags = [];
  if (fresh.has(x.id) && x.counted) tags.push(h('span', { class: 'tag new' }, '새로'));
  if (x.kind === core.KIND.WAIT) tags.push(h('span', { class: 'tag wait' }, '인출 대기'));
  return h('div', { class: `person${done ? ' done' : ''}${x.kind === core.KIND.WAIT ? ' waiting' : ''}` },
    h('p', { class: 'line' }, h('span', { class: 'name' }, x.name || `(이름 없음 ${x.id})`), ...tags, core.lapsedParts(x, { cur, last, prior }).join(' · ')),
    h('label', { class: 'contact' }, box, '연락함'),
    h('div', { class: 'months', 'aria-label': '달별 납부' }, cells));
}

async function setContacted(cur, id, on) {
  // 화면이 들고 있는 값이 아니라 저장소에서 바로 읽는다(빠르게 두 번 눌러도 앞의 표시가 사라지지 않게)
  const contacted = { ...((await chrome.storage.local.get('contacted')).contacted || {}) };
  const key = `${cur}:${id}`;
  if (on) contacted[key] = Date.now();
  else delete contacted[key];
  // 지난달 이전 표시는 정리(이번 달 기준으로 저장)
  for (const k of Object.keys(contacted)) if (k.slice(0, 7) < core.monthAdd(cur, -3)) delete contacted[k];
  await chrome.storage.local.set({ contacted });
  chrome.runtime.sendMessage({ type: 'badge' });
}

for (const id of ['f-region', 'f-kind', 'f-hide', 'f-prior']) $(id).addEventListener('change', renderLapsed);
$('f-q').addEventListener('input', renderLapsed);

$('lapsed-xlsx').addEventListener('click', () => {
  if (!lapsedRes) return;
  const { cur } = lapsedRes;
  // 필터와 상관없이 명단 전체를 저장한다(PRD 3.2)
  const aoa = core.lapsedAoa(lapsedRes.list, { cur, prior: settings().prior }, contactedSet(cur));
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = aoa[0].map((hd, i) => ({ wch: i === 10 ? 20 : i === 3 ? 14 : Math.max(8, String(hd).length + 2) }));
  ws['!autofilter'] = { ref: ws['!ref'] };
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, '미납자 명단');
  XLSX.writeFile(wb, `당비미납_${cur}_${today()}.xlsx`);
  toast('명단 전체를 엑셀로 내려받았습니다. 이름·연락처가 들어 있으니 다른 곳에 올리지 마세요.');
});

// ------------------------------------------------------------------ 표 그리기·복사·엑셀 공용

// head: [[{text, rowspan, colspan}|문자, …], …], body: [[문자…]…] (마지막 줄 = 총계)
function drawTable(table, head, body) {
  table.replaceChildren();
  const thead = h('thead');
  for (const row of head) {
    thead.append(h('tr', {}, row.map((c) => (typeof c === 'string'
      ? h('th', {}, c)
      : h('th', { rowspan: c.rowspan, colspan: c.colspan }, c.text)))));
  }
  const tbody = h('tbody');
  body.forEach((r, i) => {
    tbody.append(h('tr', { class: i === body.length - 1 ? 'total' : null }, r.map((v, j) => h('td', {
      class: j === r.length - 1 && head[0].some((c) => (c.text || c) === '비고') ? 'note' : /^-\d/.test(v) ? 'neg' : null,
    }, v))));
  });
  table.append(thead, tbody);
}

// 한글에 붙여넣을 수 있게 HTML 표(선 있음) + 일반 글자(탭 구분) 둘 다 클립보드에
async function copyTable(head, body, title) {
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
  const td = 'border:1px solid #000;padding:2px 6px;';
  let html = `<table style="border-collapse:collapse;font-size:10pt">`;
  for (const row of head) {
    html += '<tr>' + row.map((c) => (typeof c === 'string'
      ? `<th style="${td}background:#eee">${esc(c)}</th>`
      : `<th style="${td}background:#eee"${c.rowspan ? ` rowspan="${c.rowspan}"` : ''}${c.colspan ? ` colspan="${c.colspan}"` : ''}>${esc(c.text)}</th>`)).join('') + '</tr>';
  }
  for (const r of body) {
    html += '<tr>' + r.map((v, j) => `<td style="${td}text-align:${j === 0 ? 'left' : 'right'}">${esc(v)}</td>`).join('') + '</tr>';
  }
  html += '</table>';
  const text = [title, ...head.map((r) => r.map((c) => (typeof c === 'string' ? c : c.text.replace(/\n/g, ' '))).join('\t')), ...body.map((r) => r.join('\t'))].filter(Boolean).join('\n');
  try {
    await navigator.clipboard.write([new ClipboardItem({
      'text/html': new Blob([html], { type: 'text/html' }),
      'text/plain': new Blob([text], { type: 'text/plain' }),
    })]);
    toast('표를 복사했습니다. 한글에서 붙여넣기(Ctrl+V, 맥은 ⌘+V) 하세요.');
  } catch {
    toast('복사하지 못했습니다. 화면을 한 번 누른 뒤 다시 눌러 주세요.');
  }
}

// 2단 머리를 엑셀 칸 합치기로
function headToAoa(head) {
  const width = head[0].reduce((s, c) => s + (typeof c === 'string' ? 1 : c.colspan || 1), 0);
  const grid = head.map(() => Array(width).fill(''));
  const merges = [];
  const taken = head.map(() => Array(width).fill(false));
  head.forEach((row, r) => {
    let col = 0;
    for (const c of row) {
      while (taken[r][col]) col += 1;
      const text = typeof c === 'string' ? c : c.text.replace(/\n/g, '');
      const rs = (typeof c === 'string' ? 1 : c.rowspan) || 1;
      const cs = (typeof c === 'string' ? 1 : c.colspan) || 1;
      grid[r][col] = text;
      for (let i = 0; i < rs; i++) for (let j = 0; j < cs; j++) taken[r + i][col + j] = true;
      if (rs > 1 || cs > 1) merges.push({ s: { r, c: col }, e: { r: r + rs - 1, c: col + cs - 1 } });
      col += cs;
    }
  });
  return { grid, merges };
}

function saveTableXlsx({ head, body, notes, title, sheet, file }) {
  const { grid, merges } = headToAoa(head);
  const top = title ? [[title], []] : [];
  const aoa = [...top, ...grid, ...body, [], ...notes.map((n) => [`※ ${n}`])];
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!merges'] = merges.map((m) => ({ s: { r: m.s.r + top.length, c: m.s.c }, e: { r: m.e.r + top.length, c: m.e.c } }));
  ws['!cols'] = grid[0].map((_, i) => ({ wch: i === 0 ? 14 : 11 }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheet);
  XLSX.writeFile(wb, file);
  toast('엑셀 파일을 내려받았습니다.');
}

// ------------------------------------------------------------------ 당원현황

let memberView = null;
let memberCompare = null; // 사용자가 고른 비교 기준일(안 골랐으면 가장 최근 기록)

function renderMembers() {
  const ledger = store.ledger || core.seedLedger();
  const dates = core.ledgerDates(ledger);
  const date = dates.at(-1);
  if (!date) {
    $('m-compare').replaceChildren();
    $('m-title').textContent = '아직 기록이 없습니다. 당원관리 시스템에 로그인한 뒤 [지금 확인]을 눌러 주세요. 9기 누계를 보려면 설정 → [장부 가져오기]로 출발점 장부 파일을 넣어 주세요.';
    $('m-summary').textContent = '';
    $('m-table').replaceChildren();
    $('m-notes').replaceChildren();
    memberView = null;
    return;
  }
  const earlier = dates.filter((d) => d < date);
  const sel = $('m-compare');
  sel.replaceChildren(...earlier.slice().reverse().map((d) => h('option', { value: d }, d)));
  if (memberCompare && earlier.includes(memberCompare)) sel.value = memberCompare;
  const s = settings();
  const rep = core.memberReport({ ledger, date, compareDate: sel.value || null, termStart: s.termStart, yearStart: s.yearStart });
  if (!rep) return;
  const t = core.memberReportTable(rep);
  const title = `당원현황 (${date} 기준)`;
  $('m-title').textContent = store.members ? `${date} 기록 기준` : `${date} 기록 기준 — 아직 [지금 확인]을 하지 않아 가져온 장부의 숫자입니다.`;
  $('m-summary').textContent = rep.summary;
  drawTable($('m-table'), [t.head1, t.head2], t.body);
  $('m-notes').replaceChildren(...t.notes.map((n) => h('li', {}, n)));
  memberView = { head: [t.head1, t.head2], body: t.body, notes: [rep.summary, ...t.notes], title, date };
}

$('m-compare').addEventListener('change', () => {
  memberCompare = $('m-compare').value;
  renderMembers();
});
$('m-copy').addEventListener('click', () => memberView && copyTable(memberView.head, memberView.body, ''));
$('m-xlsx').addEventListener('click', () => memberView && saveTableXlsx({
  ...memberView, sheet: '당원현황', file: `당원현황_${memberView.date}.xlsx`,
}));

// ------------------------------------------------------------------ 당비현황

let feeView = null;

function renderFee() {
  const months = Object.keys(store.fee || {}).sort().reverse();
  if (!months.length) {
    $('fee-empty').hidden = false;
    $('fee-body').hidden = true;
    return;
  }
  $('fee-empty').hidden = true;
  $('fee-body').hidden = false;
  const sel = $('fee-month');
  const keep = sel.value;
  sel.replaceChildren(...months.map((m) => h('option', { value: m }, `${m.slice(0, 4)}년 ${Number(m.slice(5))}월`)));
  const lastMonth = core.monthAdd(core.monthOf(today()), -1);
  sel.value = months.includes(keep) ? keep : months.includes(lastMonth) ? lastMonth : months[0];
  const rep = core.feeReport({ fee: store.fee, special: store.special, month: sel.value });
  const t = core.feeReportTable(rep);
  drawTable($('fee-table'), [t.head], t.body);
  $('fee-notes').replaceChildren(...t.notes.map((n) => h('li', {}, n)));
  feeView = { head: [t.head], body: t.body, notes: t.notes, title: `당비현황 (${sel.value})`, month: sel.value };
}

$('fee-month').addEventListener('change', renderFee);
$('fee-copy').addEventListener('click', () => feeView && copyTable(feeView.head, feeView.body, ''));
$('fee-xlsx').addEventListener('click', () => feeView && saveTableXlsx({
  ...feeView, sheet: '당비현황', file: `당비현황_${feeView.month}.xlsx`,
}));

// ------------------------------------------------------------------ 설정

function renderSettings() {
  const s = settings();
  for (const r of document.querySelectorAll('input[name=schedule]')) r.checked = r.value === s.schedule;
  if (document.activeElement !== $('s-term')) $('s-term').value = s.termStart || '';
  if (document.activeElement !== $('s-year')) $('s-year').value = s.yearStart || '';
  const items = [];
  items.push(store.members
    ? `당원 명단: ${core.fmtNum(store.members.rows.length)}명 (${store.members.date} 받음)`
    : '당원 명단: 아직 없음');
  const fm = Object.keys(store.fee || {}).sort();
  items.push(`당비 내역: ${fm.length ? fm.map((m) => `${Number(m.slice(5))}월`).join(', ') : '아직 없음'}`);
  const ld = core.ledgerDates(store.ledger || []);
  items.push(`장부 기록일: ${ld.length}개 (${ld[0] || '-'} ~ ${ld.at(-1) || '-'})`);
  items.push(`연락함 표시: ${Object.keys(store.contacted || {}).length}건`);
  $('s-summary').replaceChildren(...items.map((t) => h('li', {}, t)));
}

for (const r of document.querySelectorAll('input[name=schedule]')) {
  r.addEventListener('change', async () => {
    await chrome.storage.local.set({ settings: { ...settings(), schedule: r.value } });
    toast(r.value === 'off' ? '자동 확인을 껐습니다.' : '자동 확인 주기를 바꿨습니다.');
  });
}

$('s-dates-save').addEventListener('click', async () => {
  const term = $('s-term').value;
  if (!term) {
    toast('9기 시작일을 넣어 주세요.');
    return;
  }
  await chrome.storage.local.set({ settings: { ...settings(), termStart: term, yearStart: $('s-year').value } });
  toast('누계 기준일을 저장했습니다. 당원현황 표에 바로 반영됩니다.');
});

$('s-ledger-out').addEventListener('click', () => {
  const ws = XLSX.utils.aoa_to_sheet(core.ledgerToAoa(store.ledger || core.seedLedger()));
  ws['!cols'] = core.LEDGER_COLS.map((c, i) => ({ wch: i === 6 ? 24 : 12 }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, '당원');
  XLSX.writeFile(wb, `당원현황_누계_${today()}.xlsx`);
  toast('장부를 내려받았습니다.');
});

let pendingLedger = null;
$('s-ledger-in').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    // 날짜는 글자로 읽는다(날짜 객체는 시간대 때문에 하루 밀릴 수 있음)
    const wb = XLSX.read(await file.arrayBuffer(), { type: 'array', dateNF: 'yyyy-mm-dd' });
    const ws = wb.Sheets['당원'] || wb.Sheets[wb.SheetNames[0]];
    const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false, dateNF: 'yyyy-mm-dd', defval: null });
    const r = core.ledgerFromAoa(aoa);
    pendingLedger = r.ledger;
    $('s-ledger-msg').textContent = `"${file.name}": 기록일 ${r.dates.length}개(${r.dates[0]} ~ ${r.dates.at(-1)}), ${r.ledger.length}줄을 읽었습니다.` +
      (r.skipped ? ` 날짜나 지역이 비어 건너뛴 줄 ${r.skipped}개가 있습니다.` : '') +
      ' 지금 장부를 통째로 이 파일 내용으로 바꿉니다.';
    $('s-ledger-confirm').hidden = false;
  } catch (err) {
    pendingLedger = null;
    $('s-ledger-confirm').hidden = true;
    toast(`장부를 읽지 못했습니다: ${err.message}`);
  }
});
$('s-ledger-apply').addEventListener('click', async () => {
  if (!pendingLedger) return;
  await chrome.storage.local.set({ ledger: pendingLedger });
  pendingLedger = null;
  $('s-ledger-confirm').hidden = true;
  toast('장부를 바꿨습니다. 당원현황 표에 바로 반영됩니다.');
});
$('s-ledger-cancel').addEventListener('click', () => {
  pendingLedger = null;
  $('s-ledger-confirm').hidden = true;
});

$('s-reset').addEventListener('click', () => ($('s-reset-confirm').hidden = false));
$('s-reset-no').addEventListener('click', () => ($('s-reset-confirm').hidden = true));
$('s-reset-yes').addEventListener('click', async () => {
  $('s-reset-confirm').hidden = true;
  await chrome.runtime.sendMessage({ type: 'reset' });
  toast('모든 자료를 지웠습니다.');
});

// ------------------------------------------------------------------ 시작

async function renderAll() {
  await reload();
  renderTop();
  renderLapsed();
  renderMembers();
  renderFee();
  renderSettings();
}

let pending = null;
chrome.storage.onChanged.addListener((_changes, area) => {
  if (area !== 'local') return;
  clearTimeout(pending);
  pending = setTimeout(renderAll, 50); // 여러 칸이 한꺼번에 바뀌면 한 번만 다시 그림
});

let first = 'lapsed';
try {
  first = TABS.includes(localStorage.getItem('tab')) ? localStorage.getItem('tab') : 'lapsed';
} catch {
  /* 기본 탭 */
}
showTab(first);
renderAll();
