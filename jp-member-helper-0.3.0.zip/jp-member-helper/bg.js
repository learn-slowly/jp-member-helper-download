// 백그라운드: 알람, 자료 받기(siteFetch), 알림, 아이콘 숫자.
// 계산은 전부 core.js. 자료는 chrome.storage.local에만 둔다(바깥으로 보내지 않음).
import * as core from './core.js';

const SITE = 'https://cs.justice21.org';
const SITE_HOME = `${SITE}/memberAdmin/`;
const DASHBOARD = chrome.runtime.getURL('dashboard.html');
const LOGIN_RETRY_MAX = 20;

// ------------------------------------------------------------------ 저장소

const load = (keys) => chrome.storage.local.get(keys);
const save = (obj) => chrome.storage.local.set(obj);

async function setStatus(text, busy = false) {
  await save({ status: { text, busy, at: Date.now() } });
}

async function settings() {
  const { settings: s } = await load('settings');
  return { ...core.DEFAULT_SETTINGS, ...(s || {}) };
}

// 처음 설치하면 설정과 빈 장부를 넣는다(출발점 장부는 설정에서 가져온다)
async function init() {
  const got = await load(['settings', 'ledger', 'meta']);
  const put = {};
  if (!got.settings) put.settings = { ...core.DEFAULT_SETTINGS };
  if (!got.ledger) put.ledger = core.seedLedger();
  if (!got.meta) put.meta = { lastSync: 0, lastAutoOk: '', loginNoticeDay: '', loginRetries: 0 };
  if (Object.keys(put).length) await save(put);
  // 확인 도중 브라우저가 꺼졌으면 '확인 중' 표시가 남아 버튼이 잠긴다 → 풀어 준다
  const { status } = await load('status');
  if (status?.busy && !running) await setStatus('지난 확인이 중간에 끊겼습니다. [지금 확인]을 다시 눌러 주세요.');
  // 한 시간마다 "오늘 확인할 차례인가"만 본다(실제 확인은 하루 한 번)
  if (!(await chrome.alarms.get('tick'))) chrome.alarms.create('tick', { delayInMinutes: 1, periodInMinutes: 60 });
  await updateBadge();
}

chrome.runtime.onInstalled.addListener(init);
chrome.runtime.onStartup.addListener(init);

// ------------------------------------------------------------------ 사이트에서 자료 받기

// 사이트 탭 안에서 실행된다. 바깥 변수·import를 쓰면 안 된다(그대로 복사되어 들어감).
// 읽기 전용: 목록 페이지 1번 + 엑셀 내려받기 요청만 한다.
async function siteFetch({ feeMonths, specialMonths }) {
  const base = '/memberAdmin/memberMgr/';
  const decode = (buf) => {
    try {
      return new TextDecoder('utf-8', { fatal: true }).decode(buf);
    } catch {
      return new TextDecoder('euc-kr').decode(buf);
    }
  };
  const request = async (path, body) => {
    const res = await fetch(base + path, body ? { method: 'POST', body, credentials: 'include' } : { credentials: 'include' });
    if (!res.ok) throw new Error(`사이트 응답 ${res.status} (${path})`);
    return decode(await res.arrayBuffer());
  };
  const formBody = (form, extra = {}) => {
    const p = new URLSearchParams();
    for (const el of form.querySelectorAll('input, select, textarea')) {
      if (!el.name || el.disabled) continue;
      if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) continue;
      if (el.tagName === 'SELECT') {
        const opt = el.querySelector('option[selected]') || el.querySelector('option');
        p.append(el.name, opt ? opt.value : '');
      } else {
        p.append(el.name, el.value ?? '');
      }
    }
    for (const [k, v] of Object.entries(extra)) p.set(k, v);
    return p;
  };
  try {
    const listHtml = await request('memberList.php');
    const doc = new DOMParser().parseFromString(listHtml, 'text/html');
    const dataForm = doc.querySelector('form[name=dataForm]');
    const goForm = doc.querySelector('form[name=goForm]');
    if (!dataForm && !goForm) return { login: false };
    if (!dataForm || !goForm) return { error: '사이트 목록 화면의 양식이 바뀌었을 수 있습니다.' };
    const members = await request('memberExcel.php', formBody(goForm));
    const fee = {};
    for (const m of feeMonths) {
      const [y, mm] = m.split('-');
      fee[m] = await request('memberFeeExcel.php', formBody(dataForm, { key_year: y, key_month: mm }));
    }
    const special = {};
    for (const m of specialMonths) {
      const [y, mm] = m.split('-');
      special[m] = await request('memberSuFeeExcel.php', formBody(dataForm, { key_year: y, key_month: mm }));
    }
    return { login: true, members, fee, special };
  } catch (e) {
    return { error: String(e && e.message ? e.message : e) };
  }
}

// 사이트 탭을 찾거나(있으면 재사용) 안 보이게 하나 열어서 siteFetch를 실행한다
async function runInSiteTab(args) {
  const tabs = await chrome.tabs.query({ url: `${SITE}/*` });
  let tab = tabs.find((t) => t.status === 'complete') || tabs[0];
  let opened = false;
  if (!tab) {
    tab = await chrome.tabs.create({ url: SITE_HOME, active: false });
    opened = true;
    await waitForLoad(tab.id);
  }
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: siteFetch, args: [args] });
    return res.result;
  } finally {
    if (opened) chrome.tabs.remove(tab.id).catch(() => {});
  }
}

function waitForLoad(tabId, ms = 30000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(on);
      reject(new Error('사이트가 열리지 않습니다. 인터넷 연결을 확인해 주세요.'));
    }, ms);
    const on = (id, info) => {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(on);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(on);
  });
}

// ------------------------------------------------------------------ 확인하기

let running = false;

// auto: 자동 확인인지(로그인 알림·재시도 방식이 다름)
async function runCheck({ auto = false } = {}) {
  if (running) return { ok: false, text: '이미 확인 중입니다.' };
  running = true;
  // 사이트 응답을 기다리는 1~2분 동안 백그라운드가 잠들지 않게 20초마다 깨운다
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(), 20000);
  try {
    await setStatus('자료를 받는 중입니다… (1~2분)', true);
    const s = await settings();
    const now = new Date();
    const today = core.localDate(now);
    const cur = core.monthOf(today);
    const store = await load(['fee', 'special', 'ledger', 'snapshots', 'notified', 'meta', 'contacted']);
    const feeMonths = core.feeMonthsToFetch(cur, Object.keys(store.fee || {}), s.prior);
    const specialMonths = [core.monthAdd(cur, -1), cur];

    const got = await runInSiteTab({ feeMonths, specialMonths });
    const meta = { ...(store.meta || {}) };
    if (!got || got.error) {
      const text = `확인하지 못했습니다: ${got ? got.error : '알 수 없는 오류'} 잠시 뒤 [지금 확인]을 다시 눌러 주세요.`;
      await setStatus(text);
      return { ok: false, text };
    }
    if (!got.login) {
      await loginNeeded(meta, today, auto);
      return { ok: false, text: '당원관리 시스템에 로그인한 뒤 [지금 확인]을 눌러 주세요.' };
    }

    // 읽기 → 최소 수집 정규화(필수 칸 없으면 SiteFormatError로 멈춤)
    const members = core.normalizeMembers(core.parseHtmlTable(got.members));
    const fee = { ...(store.fee || {}) };
    for (const [m, text] of Object.entries(got.fee)) {
      fee[m] = { fetchedAt: Date.now(), rows: core.normalizeFee(core.parseHtmlTable(text), m) };
    }
    const special = { ...(store.special || {}) };
    for (const [m, text] of Object.entries(got.special)) {
      special[m] = { fetchedAt: Date.now(), rows: core.normalizeSpecial(core.parseHtmlTable(text)) };
    }

    // 장부에 오늘 줄
    // 장부는 쓰기 직전에 다시 읽는다(확인하는 1~2분 사이 설정에서 가져온 장부를 덮어쓰지 않게)
    const fresh0 = await load(['ledger', 'snapshots']);
    const ledger = fresh0.ledger || core.seedLedger();
    const snapshots = fresh0.snapshots || {};
    const prevDate = core.ledgerDates(ledger.filter((r) => r.date < today)).pop() || null;
    const rec = core.recordDay({ ledger, members, date: today, prevDate, prevSnapshot: prevDate ? snapshots[prevDate] || null : null });
    snapshots[today] = rec.snapshot;

    // 미납자와 새 미납 알림
    const res = core.findLapsed({ feeByMonth: fee, members, today, prior: s.prior });
    const notified = { ...(store.notified || {}) };
    const fresh = core.newLapsed(res.list, notified[cur] || []);
    if (fresh.length) {
      notified[cur] = [...(notified[cur] || []), ...fresh.map((x) => x.id)];
      notifyNew(fresh);
    }

    meta.lastSync = Date.now();
    meta.lastNew = fresh.map((x) => x.id); // 화면의 "새로" 표시
    meta.loginRetries = 0;
    if (auto) meta.lastAutoOk = today;
    await save({
      members: { date: today, rows: members },
      fee: core.keepLatest(fee, 13),
      special: core.keepLatest(special, 13),
      ledger: rec.ledger,
      snapshots: core.keepLatest(snapshots, 5),
      notified: core.keepLatest(notified, 4),
      meta,
    });
    chrome.alarms.clear('login-retry');
    const c = res.counts;
    const text = `확인 완료 · 당원 ${members.length.toLocaleString('ko-KR')}명 · 미납 ${c.total}명` +
      (fresh.length ? ` (새로 ${fresh.length}명)` : '');
    await setStatus(text);
    await updateBadge();
    return { ok: true, text };
  } catch (e) {
    const text = e instanceof core.SiteFormatError
      ? `${e.message} 숫자를 만들지 않고 멈췄습니다. 개발 담당자에게 알려 주세요.`
      : `확인하지 못했습니다: ${e.message} 잠시 뒤 다시 눌러 주세요.`;
    await setStatus(text);
    return { ok: false, text };
  } finally {
    clearInterval(keepAlive);
    running = false;
  }
}

// 로그인 안 됨: 같은 날 알림은 한 번만, 1분마다 최대 20번 조용히 다시 시도
async function loginNeeded(meta, today, auto) {
  // 다시 시도 횟수는 그날 처음 실패했을 때와 사용자가 직접 눌렀을 때 새로 센다
  if (meta.loginNoticeDay !== today || !auto) meta.loginRetries = 0;
  if (meta.loginNoticeDay !== today) {
    meta.loginNoticeDay = today;
    chrome.notifications.create('login', {
      type: 'basic',
      iconUrl: 'icons/128.png',
      title: '당원관리 도우미',
      message: '당원관리 시스템에 로그인해 주세요. 로그인하면 자동으로 이어서 확인합니다.',
      priority: 1,
    });
  }
  meta.loginRetries = (meta.loginRetries || 0) + 1;
  await save({ meta });
  await setStatus('당원관리 시스템에 로그인한 뒤 [지금 확인]을 눌러 주세요.');
  if (meta.loginRetries < LOGIN_RETRY_MAX) {
    chrome.alarms.create('login-retry', { delayInMinutes: 1 });
    await save({ retryAuto: auto });
  }
}

function notifyNew(fresh) {
  const by = {};
  for (const x of fresh) by[x.region] = (by[x.region] || 0) + 1;
  const parts = core.regionSort(Object.keys(by)).map((r) => `${r} ${by[r]}`);
  chrome.notifications.create(`lapsed-${Date.now()}`, {
    type: 'basic',
    iconUrl: 'icons/128.png',
    title: `새 당비 미납 ${fresh.length}명`,
    message: parts.join(', '),
    priority: 2,
  });
}

// 아이콘 숫자 = 아직 연락하지 않은 이번 달 미납자 수
async function updateBadge() {
  const store = await load(['fee', 'members', 'contacted', 'settings']);
  if (!store.members || !store.fee) {
    await chrome.action.setBadgeText({ text: '' });
    return;
  }
  const today = core.localDate(new Date());
  const cur = core.monthOf(today);
  const s = { ...core.DEFAULT_SETTINGS, ...(store.settings || {}) };
  const res = core.findLapsed({ feeByMonth: store.fee, members: store.members.rows, today, prior: s.prior });
  const contacted = store.contacted || {};
  const n = res.list.filter((x) => x.counted && !contacted[`${cur}:${x.id}`]).length;
  await chrome.action.setBadgeBackgroundColor({ color: '#B3261E' });
  await chrome.action.setBadgeText({ text: n ? String(n) : '' });
}

// ------------------------------------------------------------------ 알람·알림·화면 연결

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'tick') {
    const s = await settings();
    const { meta } = await load('meta');
    const now = new Date();
    if (core.shouldAutoRun({ schedule: s.schedule, today: core.localDate(now), hour: now.getHours(), weekday: now.getDay(), lastAutoOk: meta?.lastAutoOk })) {
      await runCheck({ auto: true });
    }
  } else if (alarm.name === 'login-retry') {
    const { retryAuto } = await load('retryAuto');
    await runCheck({ auto: Boolean(retryAuto) });
  }
});

async function openDashboard() {
  // tabs 권한 없이 우리 화면 탭을 찾는다(크롬 116+)
  const [ctx] = await chrome.runtime.getContexts({ contextTypes: ['TAB'], documentUrls: [DASHBOARD] });
  if (ctx) {
    await chrome.tabs.update(ctx.tabId, { active: true });
    await chrome.windows.update(ctx.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: DASHBOARD });
  }
}

chrome.action.onClicked.addListener(openDashboard);
chrome.notifications.onClicked.addListener((id) => {
  chrome.notifications.clear(id);
  if (id === 'login') chrome.tabs.create({ url: SITE_HOME });
  else openDashboard();
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === 'check') {
    runCheck({ auto: false }).then(reply);
    return true; // 답을 나중에 보낸다
  }
  if (msg?.type === 'reset') {
    // 모든 자료 지우기 → 처음 설치한 상태(설정 기본값 + 빈 장부)
    chrome.storage.local.clear()
      .then(() => chrome.alarms.clear('login-retry'))
      .then(init)
      .then(() => setStatus('저장된 자료를 모두 지웠습니다. 로그인한 뒤 [지금 확인]을 눌러 주세요.'))
      .then(() => reply({ ok: true }));
    return true;
  }
  if (msg?.type === 'badge') {
    updateBadge().then(() => reply({ ok: true }));
    return true;
  }
  return false;
});
